import { Component, OnInit } from '@angular/core';
import { LocationsService } from '../../service/location/locations.service';
import { User } from '../../model/user';
import {FormsModule} from '@angular/forms';
import { UserprofileService } from '../../service/userprofile/userprofile.service';
import { UserdataService } from '../../service/userdata/userdata.service';
import { Router } from '../../../../node_modules/@angular/router';
import { UpdateprofileService } from '../../service/userprofile/updateprofile.service';
import Swal from 'sweetalert2';
import { SessionService } from '../../service/authentication/session.service';
@Component({
  selector: 'app-updateprofile',
  templateUrl: './updateprofile.component.html',
  styleUrls: ['./updateprofile.component.scss']
})
export class UpdateprofileComponent implements OnInit {

  user : User = new User();
  oldDetails : User = new User();
  cities !: string[];
  id!:number;
  fullname!:string;

  constructor(private locationService:LocationsService,private sessionService:SessionService,private updateProfileService:UpdateprofileService,private router:Router,private userdataService:UserdataService, private userprofileService:UserprofileService) { }

  ngOnInit(): void {
    this.cities = this.locationService.getLocation();
    console.log(this.cities);
    this.id = this.userdataService.getData().userid;
    console.log("my profile component id:"+this.id);
    this.userprofileService.getUserProfile(this.id).subscribe(response => {
      // this.user=new User();
      console.log(response);
      this.user = response;
      this.oldDetails = Object.assign({}, response);
      console.log(this.oldDetails);
      console.log(this.user);
    });
  }

  goToProfile(){
    this.router.navigate(['/myprofile']);
  }

  checkDetails(){
    console.log("old details");
    console.log(this.oldDetails);
    let count = 0;
    if(this.oldDetails.fullName !== this.user.fullName)
    {

      count++;
    }
    if(this.oldDetails.username !== this.user.username){
      count++;
    }
    if(this.oldDetails.email !== this.user.email){
      count++;
    }
    if(this.oldDetails.phoneNumber !== this.user.phoneNumber){
      count++;
    }
    if(this.oldDetails.location !== this.user.location){
      count++;
    }

    if(count > 0){
      this.modifyProfile();
      console.log("count is "+count);
      console.log(this.user);
      console.log(this.oldDetails);
    }
    else{
      console.log("count is "+count);
      console.log(this.user);
      console.log(this.oldDetails);
      Swal.fire("Success","Profile Data Updated","success");
      this.router.navigate(['/myprofile']);
    }

  }
  modifyProfile(){
    console.log(this.user);
    this.updateProfileService.editProfile(this.user,this.id).subscribe(response =>{
      console.log(response);
      this.sessionService.setUpdatedSession(response);
        // this.sessionService.setSession(response);
        // alert("Successfully edited !");
        Swal.fire("Success","Profile Data Updated , Kindly Refresh for updated Profile","success");
        // location.reload();
        this.router.navigate(['/myprofile']);

    },
    error => {
      console.log(error);
      Swal.fire("Error",error,"error");
    }
  );
  }
}
