package com.truebill.dev.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class NewMaker {
    @NotEmpty(message = "Maker cannot be empty")
    private String maker;
    @NotEmpty(message = "Maker cannot be empty")
    private  String vehicleType;
}
