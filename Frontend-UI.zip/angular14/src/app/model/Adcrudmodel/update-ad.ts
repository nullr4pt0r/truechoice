export interface UpdateAd {
    vehicleId: number;
    vehicleRegno: string;
    vehicleKms: string;
    vehiclePrice: number;
    vehicleOwnercount: string;
    vehicleFinance: string;
    comments: string;
    modelId : number;
    status: number;
    sellerId ?: number;
}
