package com.truebill.dev.service;

import com.truebill.dev.controller.VehicleSearch;
import com.truebill.dev.entity.SellVehicleAd;
import com.truebill.dev.repository.SellVehicleRepository;
import com.truebill.dev.response.AdResponseLimited;
import com.truebill.dev.response.SellerAdResponse;
import com.truebill.dev.utils.SearchResult;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.truebill.dev.service.SellVehicleServiceImpl.statusToString;

@Service
public class VehicleSearchServiceImpl implements  VehicleSearchService {

    Logger logger = LoggerFactory.getLogger(VehicleSearchServiceImpl.class);
    @Autowired
    private SellVehicleRepository sellVehicleRepo;

    private ModelMapper modelmapper = new ModelMapper();
    @Override
    public ResponseEntity searchVehicles(String maker, String model, String owner, String finance, String kms, String year,String userId, Pageable pageable) {
        Long userid;
        if (userId != null && !userId.equals("")) {
            logger.info("userId String type" + userId);
            userid = Long.parseLong(userId);
            logger.info("userid long : " + userid);
        } else {
            userid = (long) -1;
            logger.info("from else userid long : " + userid);
        }
        List<SellerAdResponse> vehicles = new ArrayList<>();
        Page<SellVehicleAd> ads = sellVehicleRepo.findAllByMakerModel(maker, model, owner, finance, kms, year, pageable);
        Long totalRecords = sellVehicleRepo.countByMakerModel(maker, model, owner, finance, kms, year, userid);
        int pageRecords = pageable.getPageSize();
        logger.info("total records size");
        logger.info(String.valueOf(pageable.getPageSize()));
//        if(totalRecords == 0){
//            pageRecords = 0;
//        }
        SearchResult results = null;
        for (SellVehicleAd a : ads) {
            if (userid == -1 || a.getSeller().getUserId() != userid) {
                SellerAdResponse response = modelmapper.map(a, SellerAdResponse.class);
                response.setVehicleRegno("XXXXXXXXXX");
                response.setStatus(statusToString(a.getStatus()));
                response.setMaker(a.getModel().getMaker().getMaker());
                response.setVariant(a.getModel().getVariant());
                response.setYear(a.getModel().getYear());
                response.setModelId(a.getModel().getModelId());
                response.setCreatedAt(new SimpleDateFormat("yyyy-MM-dd").format(a.getCreatedAt()));
                response.setUpdatedAt(new SimpleDateFormat("yyyy-MM-dd").format(a.getUpdatedAt()));
                vehicles.add(response);
                logger.info("in for loop");
//                logger.info(String.valueOf(vehicles.size()));
            }
        }
        if(vehicles.size() < 1 ){
            logger.info("in condition");
            logger.info("total record size is ");
            logger.info(String.valueOf(vehicles.size()));
            return ResponseEntity.status(404).body("");
        }
        logger.info("not in condition");
        logger.info("total record size is ");
        logger.info(String.valueOf(vehicles.size()));
        results = new SearchResult(vehicles, totalRecords, pageRecords);
        return ResponseEntity.status(200).body(results);
    }

    @Override
    public ResponseEntity viewLimitedDetails(long id) {
        logger.info("id: "+id);
      Optional<SellVehicleAd> ad = sellVehicleRepo.findByvehicleId(id);
      if(ad.isPresent()){
          logger.info("Ad is present");
          AdResponseLimited response = modelmapper.map(ad,AdResponseLimited.class);
          logger.info(String.valueOf(ad.get().getModel()));
          logger.info(String.valueOf(response.getVehicleId()));
          response.setVehicleId(ad.get().getVehicleId());
          response.setModel(ad.get().getModel().getModel());
          response.setComments(ad.get().getComments());
          response.setVehicleKms(ad.get().getVehicleKms());
          response.setVehicleFinance(ad.get().getVehicleFinance());
          response.setVehicleOwnercount(ad.get().getVehicleOwnercount());
          response.setVehiclePrice(ad.get().getVehiclePrice());
          response.setStatus(statusToString(ad.get().getStatus()));
          response.setMaker(ad.get().getModel().getMaker().getMaker());
          response.setVariant(ad.get().getModel().getVariant());
          response.setYear(ad.get().getModel().getYear());
          response.setModelId(ad.get().getModel().getModelId());
          response.setCreatedAt(new SimpleDateFormat("yyyy-MM-dd").format(ad.get().getCreatedAt()));
          response.setUpdatedAt(new SimpleDateFormat("yyyy-MM-dd").format(ad.get().getUpdatedAt()));
          logger.info(String.valueOf(response.getVehicleId()));
          logger.info(response.getVehicleKms());

          return ResponseEntity.status(200).body(response);
      }
      return ResponseEntity.status(404).body("");
    }
}
