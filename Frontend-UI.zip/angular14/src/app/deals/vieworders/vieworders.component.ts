import { Component, OnInit } from '@angular/core';
import { Router } from '../../../../node_modules/@angular/router';
import { UserdataService } from '../../service/userdata/userdata.service';
import { DealRecord } from '../../model/dealRecords/dealrecord';
import { FetchaddataService } from '../../service/adservices/fetchaddata.service';
import { FetchdealdataService } from '../../service/dealService/fetchdealdata.service';

@Component({
  selector: 'app-vieworders',
  templateUrl: './vieworders.component.html',
  styleUrls: ['./vieworders.component.scss']
})
export class ViewordersComponent implements OnInit {
  orderData !: DealRecord[];
  showContent !: boolean;
  id !: number;
  dtOptions : DataTables.Settings = {};

  constructor(private router:Router , private dealDataService:FetchdealdataService,private userdataService: UserdataService) { }


  ngOnInit(): void {
    this.id = this.userdataService.getData().userid;
    console.log(this.id);
    this.dealDataService.getAllDealDataByBuyerId(this.id).subscribe(response =>{
      this.orderData = response as DealRecord[];
      console.log(response);
      console.log(this.orderData);
    });
    this.dtOptions = {
      pagingType: 'full_numbers',
      lengthMenu: [5,10,15,20],
      pageLength : 5,
      processing: true
    },
    setTimeout(()=>this.showContent=true, 250)

  }

  viewDeal(id:number){
    this.router.navigate(["/buy/bill/",id]);
  }

}
