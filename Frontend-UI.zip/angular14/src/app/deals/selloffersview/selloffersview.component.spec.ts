import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelloffersviewComponent } from './selloffersview.component';

describe('SelloffersviewComponent', () => {
  let component: SelloffersviewComponent;
  let fixture: ComponentFixture<SelloffersviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SelloffersviewComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SelloffersviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
