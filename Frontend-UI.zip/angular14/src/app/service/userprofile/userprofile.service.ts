import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs/dist/types/internal/Observable';
import { User } from '../../model/user';

@Injectable({
  providedIn: 'root'
})
export class UserprofileService {
  private baseURL = 'http://localhost:9876/api/v1';

  constructor(private httpclient:HttpClient) { }

  getUserProfile(id:number):Observable<User>{
    return this.httpclient.get(`${this.baseURL}/uid/${id}`);
  }
}
