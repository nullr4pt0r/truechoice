import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '../../../../node_modules/@angular/router';
import { FetchdealdataService } from '../../service/dealService/fetchdealdata.service';
import { UserdataService } from '../../service/userdata/userdata.service';
import { DealRecord } from '../../model/dealRecords/dealrecord';
import jspdf from 'jspdf';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-buydata',
  templateUrl: './buydata.component.html',
  styleUrls: ['./buydata.component.scss']
})
export class BuydataComponent implements OnInit {
  id!:number;
  showContent : boolean = false;
  sellerId!:number;
  buydata : any;
  dealRecord :DealRecord = new DealRecord();
  constructor(private route:ActivatedRoute, private fetchDealsService:FetchdealdataService,private userdataservice:UserdataService) { }

  ngOnInit(): void {

    this.id = this.route.snapshot.params['id'];
    console.log(this.id);
    this.sellerId = this.userdataservice.getData().userid;

    this.fetchDealsService.getDealResponseByBuyerIdAndDealId(this.id,this.sellerId)
    .subscribe(response =>{
        this.buydata = response;
        if(this.buydata.status == "SOLD"){
          this.buydata.status = "PURCHASED";
        }
        this.showContent = true;
    })
  }

  downloadPDF() {
    const data = document.getElementById('invoice-content')!;
    html2canvas(data)!.then(canvas => {
      const imgWidth = 208;
      const pageHeight = 200;
      const imgHeight = canvas.height * imgWidth / canvas.width;
      const heightLeft = imgHeight;
      const contentDataURL = canvas.toDataURL('image/png');
      const pdf = new jspdf('p', 'mm', 'a4');
      pdf.addImage(contentDataURL, 'PNG', 0, 0, imgWidth, imgHeight);
      pdf.save(`Invoice-${this.buydata.vehicleRegno}.pdf`);
    });
  }
}
