export interface Adcrud {
    vehicleId: number;
    vehicleRegno: string;
    vehicleKms: string;
    vehiclePrice: number;
    vehicleOwnercount: string;
    vehicleFinance: string;
    comments: string;
    model: string;
    maker: string;
    variant: string;
    year: string;
    status: string;
    sellerId ?: number;
    modelId : number;
}