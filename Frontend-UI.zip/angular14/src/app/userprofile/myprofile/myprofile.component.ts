import { Component, OnInit } from '@angular/core';
import { User } from '../../model/user';
import { UserprofileService } from '../../service/userprofile/userprofile.service';
import { UserdataService } from '../../service/userdata/userdata.service';
import { Router } from '../../../../node_modules/@angular/router';



@Component({
  selector: 'app-myprofile',
  templateUrl: './myprofile.component.html',
  styleUrls: ['./myprofile.component.scss']
})
export class MyprofileComponent implements OnInit {
user!:User ;
id !: number;

  constructor(private userprofileService:UserprofileService,private router:Router,private userdataService:UserdataService) { }

  ngOnInit(): void {
    this.id = this.userdataService.getData().userid;
    console.log("my profile component id:"+this.id);
    this.userprofileService.getUserProfile(this.id).subscribe(response => {
      this.user=new User();
      console.log(response);
      this.user = response;
      console.log(this.user);
    });
  }

  editProfile(){
      this.router.navigate(['/editprofile']);
  }
}
