export class User {
    fullName ?: string;
    username ?: string;
    phoneNumber ?: string;
    email ?: string;
    location ?: string;
    // userType?: string;
    // userId ?: number;
}
