package com.truebill.dev.repository;

import com.truebill.dev.entity.Users;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<Users, Long> {


    Optional<Users> findByEmail(String email);
    Optional<Users> findByUsername(String username);
    Optional<Users> findByPhoneNumber(String phoneNumber);
    Optional<Users> findByEmailAndPassword(String Email, String Password);
    boolean existsByPhoneNumber(String phoneNumber);
    boolean existsByEmail(String email);
    Page<Users> findAll(Pageable pageable);

    boolean existsByPhoneNumberOrEmail(String phoneNumber, String email);

    @Query("SELECT password FROM Users WHERE email= :email")
    String findPasswordByEmail(String email);

    Optional<Users> findByUserId(Long userid);


}
