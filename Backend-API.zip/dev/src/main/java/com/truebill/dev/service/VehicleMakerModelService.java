package com.truebill.dev.service;

import com.truebill.dev.request.NewMaker;
import com.truebill.dev.request.NewModel;
import org.springframework.http.ResponseEntity;

public interface VehicleMakerModelService {
    ResponseEntity addNewMaker(NewMaker maker);
    ResponseEntity addNewModel(NewModel model);

}
