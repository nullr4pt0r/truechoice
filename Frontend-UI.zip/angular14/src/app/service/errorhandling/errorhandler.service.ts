import { Injectable } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ErrorhandlerService {
  errorMessage:any;
  constructor() { }

  handleError(error:HttpErrorResponse){

    if(error.error instanceof ErrorEvent){
      console.error('An error occured:'+error.error.message);
    }
    else if (error.error && error.error.error instanceof Array){
      // if(!errorRes.error || !errorRes.error.message) {

        this.errorMessage = error.error.error[0];

      // return throwError(errorMessage);
      }else if(typeof error.error === "object"){
        if(error.message){
          this.errorMessage = error.message;
        }
        else{
          this.errorMessage =  "An Error Occured . Try again later";
        }
      }
    else {
      // The backend returned an unsuccessful response code.
      this.errorMessage =
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`;
    }
    return throwError(
      this.errorMessage);
  };
  }

