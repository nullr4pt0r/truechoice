import { TestBed } from '@angular/core/testing';

import { MakerserviceService } from './makerservice.service';

describe('MakerserviceService', () => {
  let service: MakerserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MakerserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
