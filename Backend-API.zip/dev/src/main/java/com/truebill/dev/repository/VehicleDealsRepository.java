package com.truebill.dev.repository;

import com.truebill.dev.entity.VehicleDeals;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface VehicleDealsRepository extends JpaRepository<VehicleDeals, Long> {

    @Query("SELECT CASE WHEN COUNT(d) > 0 THEN true ELSE false END FROM VehicleDeals d WHERE d.vehicleId = :vehicleId and d.seller.userId = :sellerId and d.dealStatus = 1")
    boolean isVehicleIdSoldBySeller(@Param("vehicleId") long vehicleId, @Param("sellerId") long sellerId);

    @Query("SELECT COUNT(d) FROM VehicleDeals d WHERE d.vehicleId = :vehicleId and d.seller.userId = :sellerId and d.dealStatus = 1")
    int countVehicleIdSoldBySeller(@Param("vehicleId") long vehicleId, @Param("sellerId") long sellerId);

    boolean existsByVehicleIdVehicleIdAndSellerUserIdAndDealStatus(long vehicleId, long sellerId, short dealStatus);
    boolean existsByVehicleIdVehicleIdAndSellerUserIdAndBuyerUserIdAndDealStatus(long vehicleId, long sellerId, long buyerId,short dealStatus);

    @Modifying
    @Transactional
    @Query("UPDATE VehicleDeals d SET d.dealStatus = 3 WHERE d.vehicleId.vehicleId = :vehicleId AND d.seller.userId = :sellerId AND d.dealStatus = :dealStatus AND d.dealStatus != 1")
    void invalidateDealsByVehicleIdAndSellerIdAndDealStatus(long vehicleId, long sellerId, short dealStatus);

    //    @Query("SELECT * FROM VehicleDeals d WHERE d.vehicleId =:vehicleId and d.seller.userId = :sellerId and d.dealStatus = :dealStatus")
    List<VehicleDeals> findByVehicleIdVehicleIdAndSellerUserIdAndDealStatus(long vehicleId, long sellerId, short dealStatus);

//    @Query("SELECT d FROM VehicleDeals d WHERE d.vehicleId = :vehicleId AND d.seller.userId = :sellerId AND d.dealStatus = :dealStatus")
//    Optional<List<VehicleDeals>> findByVehicleIdAndSellerUserIdAndDealStatus

    Page<VehicleDeals> findBySellerUserId(long userId,Pageable pageable);
    Page<VehicleDeals> findByBuyerUserId(long userId,Pageable pageable);
    long countDealIdBySellerUserId(long uid);
    long countDealIdByBuyerUserId(long uid);


    long countDealStatusBySellerUserIdAndDealStatus(long uid, short status);

    @Query("SELECT v FROM VehicleDeals v where v.id = :dealid and v.seller.userId = :uid")
    Optional<VehicleDeals> findByIdAndSellerUserId(@Param("dealid") long dealid, @Param("uid") long uid);
    Optional<VehicleDeals> findByDealId(long dealid);

    Page<VehicleDeals> findAllBySellerUserId(long uid, Pageable pageable);
    Page<VehicleDeals> findAllByBuyerUserId(long uid, Pageable pageable);
    @Query("SELECT v FROM VehicleDeals v Where v.seller.userId = :userId or v.buyer.userId = :userId ORDER BY v.createdAt Desc")
    Page<VehicleDeals> findAllByBuyerUserIdOrSellerUserId(long userId, Pageable pageable);


    Page<VehicleDeals> findAllBySellerUserIdAndDealStatus(long uid,short status, Pageable pageable);
    Page<VehicleDeals> findAllByBuyerUserIdAndDealStatus(long uid,short status, Pageable pageable);
    long countDealIdBySellerUserIdAndDealStatus(long uid,short status);
    long countDealIdByBuyerUserIdAndDealStatus(long uid,short status);

}
