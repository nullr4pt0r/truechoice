package com.truebill.dev.service;

import com.truebill.dev.request.DealRecord;
import com.truebill.dev.request.DealRequest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

public interface VehicleDealsService {
    ResponseEntity buy(DealRecord deal);
    ResponseEntity getCarSellCountByUserId(long uid);
    ResponseEntity getCarBuyCountByUserId(long uid);

    ResponseEntity getCarSellOffersCountBySellerId(long uid);
    ResponseEntity getCarBuyOfferCountByBuyerId(long uid);
    ResponseEntity getDealResponseByDealIdAndBuyerId(long dealid,long uid);

    ResponseEntity getDealResponse(long dealId,long uid);

    ResponseEntity getAllDealDataBySellerId(long uid, Pageable pageable);
    ResponseEntity getAllDealDataByBuyerId(long uid,Pageable pageable);

    ResponseEntity newDealRequest(DealRequest dealRequest);
    ResponseEntity dealAction(DealRequest dealRequest);

    ResponseEntity dealRequestResponseByDealId(long dealId);
    ResponseEntity fetchDealRequestBySellerId(long uid,Pageable pageable);

    ResponseEntity fetchDealRequestByBuyerId(long uid,Pageable pageable);

    ResponseEntity getDealResponseByDealIdAndSellerId(long dealid,long uid);
    ResponseEntity findUserDealStatus(long uid, String authid,short status);

    ResponseEntity findBySellerId(String userId,long uid, Pageable pageable);
    ResponseEntity findByBuyerId(String UserId,long uid, Pageable pageable);
    ResponseEntity findByBuyerIdOrSellerId(String userId,long uid, Pageable pageable);
}
