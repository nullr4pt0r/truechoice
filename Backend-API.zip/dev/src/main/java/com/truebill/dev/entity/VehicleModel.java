package com.truebill.dev.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;

@Entity
@Table(name = "vehiclemodel")
public class VehicleModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long modelId;
    @ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name = "makerId",referencedColumnName = "makerId")
    @JsonBackReference
    private VehicleMaker maker;
    private String model;
    private String year;
    private String variant;

    public VehicleModel() {
    }

    public VehicleModel(long modelId, VehicleMaker maker, String model, String year, String variant) {
        this.modelId = modelId;
        this.maker = maker;
        this.model = model;
        this.year = year;
        this.variant = variant;
    }

    public long getModelId() {
        return modelId;
    }

    public void setModelId(long modelId) {
        this.modelId = modelId;
    }

    public VehicleMaker getMaker() {
        return maker;
    }

    public void setMaker(VehicleMaker maker) {
        this.maker = maker;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getVariant() {
        return variant;
    }

    public void setVariant(String variant) {
        this.variant = variant;
    }
}

