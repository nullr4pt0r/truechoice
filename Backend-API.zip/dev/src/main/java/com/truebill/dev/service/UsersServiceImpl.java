package com.truebill.dev.service;


import com.truebill.dev.DTO.Login;
import com.truebill.dev.DTO.ValidUser;
import com.truebill.dev.config.PasswordEncoderConfig;
import com.truebill.dev.controller.UserController;
import com.truebill.dev.entity.Users;
import com.truebill.dev.repository.UserRepository;
import com.truebill.dev.request.UserUpdateData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import org.springframework.data.domain.Pageable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UsersServiceImpl implements  UsersService {

    Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserRepository userrepo;

    @Autowired
    private PasswordEncoderConfig passwordEncoder;


    @Override
    public ResponseEntity createUser(Users user) {
        boolean value = userrepo.existsByPhoneNumberOrEmail(user.getPhoneNumber(), user.getEmail());
        if(!value) {
            if(user.getPassword().length() < 8 && user.getPassword().length() >12 || !user.getPassword().matches("(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,10}"))
            {
                return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body("Password Length criteria is not met . Minimum 8 characters , Maximum 12 characters");
            }
            else if(!user.getPhoneNumber().matches("[6-9]{1}[0-9]{9}")){
                return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body("Phone Number  criteria is not met .");

            }
            String hashedPassword =  passwordEncoder.passwordEncoder().encode(user.getPassword());
            logger.info("Hashed Password is :"+hashedPassword);
            user.setPassword(hashedPassword);
            Users user2 = userrepo.save(user);
            ValidUser user1 = new ValidUser(user2.getUserId(),user2.getUsername(),user2.getFullName(),user2.getLocation(),user2.getUserType(),user2.getPhoneNumber());
            return ResponseEntity.status(HttpStatus.OK).body(user1);
        }
        else {
            boolean value1 = userrepo.existsByPhoneNumber(user.getPhoneNumber());
            boolean value2 = userrepo.existsByEmail(user.getEmail());
            if(value2){
                return ResponseEntity.status(HttpStatus.CONFLICT).body("Email already exists");
            }
            return ResponseEntity.status(HttpStatus.CONFLICT).body("PhoneNumber already exists");
        }
    }


    @Override
    public ResponseEntity VerifyUser(Login login) {
        String hashed;
        hashed = userrepo.findPasswordByEmail(login.getEmail());
        if(hashed == null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Either Email or Password is wrong");
        }
        logger.info("Hashed" + hashed);
        logger.info(login.getEmail());
        logger.info(login.getPassword());
        boolean isMatch = passwordEncoder.passwordEncoder().matches(login.getPassword(), hashed);
        logger.info("Value of hashed" + isMatch);
        Optional<Users> validuser;
        if (isMatch) {
            validuser = userrepo.findByEmailAndPassword(login.getEmail(), hashed);
            logger.info(validuser.toString());
            ValidUser validUser1 = null;

            if (validuser.isPresent()) {
                Users user = validuser.get();
                logger.info(user.toString());
                validUser1 = new ValidUser(user.getUserId(), user.getUsername(), user.getFullName(), user.getLocation(), user.getUserType(), user.getPhoneNumber());

            }
            return ResponseEntity.status(200).body(validUser1);
        }
            else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Either Email or Password is wrong");
            }

        }
        



    @Override
    public ResponseEntity findUser(long uid) {
        Optional<Users> user1 = userrepo.findByUserId(uid);
        if(user1.isPresent()) {
            return ResponseEntity.status(200).body(user1);
        }
        else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No Users Found");
        }
    }


    @Override
    public ResponseEntity getAllUser(@PageableDefault(value = 100) Pageable pageable) {
        List<Users> users = new ArrayList<>();
        Page<Users> user = userrepo.findAll(pageable);
        for (Users a : user.getContent()) {
            users.add(a);
        }
        return ResponseEntity.status(HttpStatus.FOUND).body(users);
    }


    public  ResponseEntity updateUser(long uid,UserUpdateData user){
        Optional<Users> users = userrepo.findByUserId(uid);
//        boolean value = userrepo.existsByPhoneNumberOrEmail(user.getPhoneNumber(), user.getEmail());
        if(users.isPresent()){
            if(userrepo.existsByEmail(user.getEmail()) && !users.get().getEmail().equals(user.getEmail())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email already exists");
            }
            else if(userrepo.existsByPhoneNumber(user.getPhoneNumber()) && !users.get().getPhoneNumber().equals(user.getPhoneNumber())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Phone Number already exists");
            }
            else{

                Users editUser = users.get();
                editUser.setEmail(user.getEmail());
//            editUser.setPassword(passwordEncoder.passwordEncoder().encode(user.getPassword()));
                editUser.setUsername(user.getUsername());
                editUser.setFullName(user.getFullName());
                editUser.setPhoneNumber(user.getPhoneNumber());
                editUser.setLocation(user.getLocation());
                editUser = userrepo.save(editUser);
                return ResponseEntity.status(HttpStatus.ACCEPTED).body(editUser);
            }

        }
        return ResponseEntity.status(404).body("User not found");
    }
}
