import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpInterceptor, HttpEvent } from '@angular/common/http';
import { UserdataService } from '../service/userdata/userdata.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SessionInterceptor implements HttpInterceptor {
  data : any;
  userId !: string;
  constructor(private userDataService: UserdataService) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
   this.data = this.userDataService.getData();
   if(this.data && this.data.userid){
     this.userId = this.data.userid.toString();
     console.log("from interceptor if else : "+this.userId);
   }

    console.log("from interceptor" + this.userId);
    console.log(typeof this.userId);
    if (this.userId != null && this.userId != undefined) {
      const authReq = req.clone({
        headers: req.headers.append("Auth", this.userId)
      });
      return next.handle(authReq);
    }
    else{
      return next.handle(req);
    }
  }
}
