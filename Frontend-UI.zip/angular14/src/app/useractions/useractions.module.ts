import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserhomeComponent } from './userhome/userhome.component';
import { SessionService } from '../service/authentication/session.service';
import { UserdataService } from '../service/userdata/userdata.service';
import { FetchaddataService } from '../service/adservices/fetchaddata.service';
import { NavBarsModule } from '../nav-bars/nav-bars/nav-bars.module';
import { FetchdealdataService } from '../service/dealService/fetchdealdata.service';



@NgModule({
  declarations: [
    UserhomeComponent
  ],
  imports: [
    CommonModule,
    NavBarsModule
  ],
  providers: [SessionService,UserdataService,FetchaddataService,FetchdealdataService],
  exports:[
    UserhomeComponent
  ]
})
export class UseractionsModule {








 }
