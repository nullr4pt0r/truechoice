package com.truebill.dev.controller;

import com.truebill.dev.repository.VehicleDealsRepository;
import com.truebill.dev.request.DealRecord;
import com.truebill.dev.request.DealRequest;
import com.truebill.dev.service.VehicleDealsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/deals")
public class DealsController {
        Logger logger = LoggerFactory.getLogger(DealsController.class);
    @Autowired
    private VehicleDealsService vehicleDealsService;
    @Autowired
    private VehicleDealsRepository vehicleDealsRepository;

    @GetMapping("/view/deals/{uid}/{status}")
    public ResponseEntity getDealsByStatus(@RequestHeader(name = "Auth", required = false) String userId,@PathVariable long uid, @PathVariable short status){
        return vehicleDealsService.findUserDealStatus(uid,userId,status);
    }

    @GetMapping("/count/{uid}/buy")
    public ResponseEntity getBuyCountByUserId(@PathVariable long uid){
        return vehicleDealsService.getCarBuyCountByUserId(uid);
    }
    @GetMapping("/count/{uid}/sell")
    public ResponseEntity getSellCountByUserId(@PathVariable long uid){
        return vehicleDealsService.getCarSellCountByUserId(uid);
    }

    @GetMapping("/sell/{uid}/{dealid}")
    public ResponseEntity getDataBySellerId(@PathVariable long uid,@PathVariable long dealid){
        return  vehicleDealsService.getDealResponseByDealIdAndSellerId(dealid,uid);
    }

    @GetMapping("/buy/{uid}/{dealid}")
    public ResponseEntity getDataByBuyerId(@PathVariable long uid,@PathVariable long dealid){
        return  vehicleDealsService.getDealResponseByDealIdAndBuyerId(dealid,uid);
    }

//    @PostMapping("/new/deal")
//    public ResponseEntity  createNewDeal(@RequestBody DealRecord deal){
//        return vehicleDealsService.buy(deal);
//    }

    @GetMapping("/{uid}/sales")
    public  ResponseEntity getAllDealDataBySellerId(@PathVariable long uid, @PageableDefault(value = 100)Pageable pageable){
        return vehicleDealsService.getAllDealDataBySellerId(uid,pageable);
    }

    @GetMapping("/{uid}/orders")
    public  ResponseEntity getAllDealDataByBuyerId(@PathVariable long uid, @PageableDefault(value = 100)Pageable pageable){
        return vehicleDealsService.getAllDealDataByBuyerId(uid,pageable);
    }

    @GetMapping("/users/{uid}/seller")
    public ResponseEntity getAllDealsBySellerIdAndStatus(@PathVariable long uid,@PageableDefault(value = 100)Pageable pageable){
        return vehicleDealsService.fetchDealRequestBySellerId(uid,pageable);
    }

    @GetMapping("/{uid}/buyer")
    public ResponseEntity getAllDealsByBuyerIdAndStatus(@PathVariable long uid,@PageableDefault(value = 100)Pageable pageable){
        return vehicleDealsService.fetchDealRequestByBuyerId(uid,pageable);
    }

    @PostMapping("new/request")
    public ResponseEntity createNewDealRequest(@RequestBody DealRequest dealRequest){
        logger.info(String.valueOf(dealRequest.getBuyerQuote()));
        return vehicleDealsService.newDealRequest(dealRequest);
    }

    @PostMapping("/seller/action")
    public ResponseEntity dealActionBySeller(@RequestBody DealRequest dealRequest){
        return vehicleDealsService.dealAction(dealRequest);
    }

    @GetMapping("/{uid}/offers/sell")
    public ResponseEntity offerCountBySellerId(@PathVariable long uid){
        return  vehicleDealsService.getCarSellOffersCountBySellerId(uid);
    }

    @GetMapping("/{uid}/offers/buy")
    public ResponseEntity offerCountByBuyerId(@PathVariable long uid){
        return  vehicleDealsService.getCarBuyOfferCountByBuyerId(uid);
    }

    @GetMapping("/id/{id}")
    public ResponseEntity findDealByDealId(@PathVariable long id){
        return ResponseEntity.status(200).body(vehicleDealsRepository.findByDealId(id));
    }

    @GetMapping("/request/{dealId}")
    public  ResponseEntity dealRequestByDealId(@PathVariable long dealId){
        return  vehicleDealsService.dealRequestResponseByDealId(dealId);
    }

    @GetMapping("/seller/{id}/history")
    public ResponseEntity sellerHistory(@RequestHeader(name = "Auth", required = true) String userId,@PathVariable long id,@PageableDefault(value = 10)Pageable pageable){
        return vehicleDealsService.findBySellerId(userId,id,pageable);
    }

    @GetMapping("/buyer/{id}/history")
    public ResponseEntity buyerHistory(@RequestHeader(name = "Auth", required = true) String userId,@PathVariable long id,@PageableDefault(value = 10)Pageable pageable){
        return vehicleDealsService.findByBuyerId(userId,id,pageable);
    }

    @GetMapping("/history/{id}")
    public ResponseEntity userHistory(@RequestHeader(name = "Auth", required = true) String userId,@PathVariable long id,@PageableDefault(value = 100)Pageable pageable){
        return vehicleDealsService.findByBuyerIdOrSellerId(userId,id,pageable);
    }
//    @GetMapping("/deals/2")
//    public ResponseEntity findNegoDeals(){
//        return  ResponseEntity.status(200).body(vehicleDealsRepository.existsByVehicleIdVehicleIdAndSellerUserIdAndDealStatus(4,4,(short)2));
//    }

}
