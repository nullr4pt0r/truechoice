import { Dealrecord } from './dealrecord';

describe('Dealrecord', () => {
  it('should create an instance', () => {
    expect(new Dealrecord()).toBeTruthy();
  });
});
