package com.truebill.dev.entity;

import com.truebill.dev.listeners.VehicleDealsListener;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
//@EntityListeners(VehicleDealsListener.class)
@Table(name = "vehicledeals")
public class VehicleDeals {
//    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "dealId", nullable = false)
    private Long dealId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "VehicleId", referencedColumnName = "vehicleId")
    private SellVehicleAd vehicleId;

//    @ManyToOne(fetch =FetchType.LAZY)
//    @JoinColumn(name = "vehicleRegno", referencedColumnName = "vehicleRegno")
    private String vehicleRegno;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sellerId" , referencedColumnName = "userId")
    private Users seller;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "buyerId", referencedColumnName = "userId")
    private Users buyer;

    @NotNull(message = "Final Quote should not be null")
    @DecimalMin(value = "0.0",message = " Vehicle Price Should not be less than 0.0")
    private double buyerQuote;
// private double sellerQuote;
//@NotNull(message = "Final Quote should not be null")
//@DecimalMin(value = "0.0",message = " Vehicle Price Should not be less than 0.0")
//@Column(nullable = false)
    private double finalQuote;

    @CreationTimestamp
    @Column(name = "created_At", nullable = false,updatable = false)
    private Date createdAt;

    //1 for sold;
    //2 for in negotiation
    //3  for rejected;
    //4 for accepted;
    private short dealStatus;

}
