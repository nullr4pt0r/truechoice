import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewadbyidComponent } from './viewadbyid.component';

describe('ViewadbyidComponent', () => {
  let component: ViewadbyidComponent;
  let fixture: ComponentFixture<ViewadbyidComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewadbyidComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewadbyidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
