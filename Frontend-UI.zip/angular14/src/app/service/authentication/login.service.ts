import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { LoginModel } from '../../model/login';
import { Router } from '@angular/router';
import {SessionService} from '../authentication/session.service';
import {Observable,throwError} from 'rxjs';
import {catchError} from 'rxjs/operators';
import Swal from 'sweetalert2';
@Injectable({
  providedIn: 'root'
})
export class LoginService {
  // private readonly mockedUser =  new LoginModel('johnkay@gmail.com','12345');



  private baseURL = "http://localhost:9876/api/v1";

  constructor(private httpClient:HttpClient, private sessionService:SessionService, private router:Router) { }

  login(login:LoginModel) : Observable<Object>{
    return this.httpClient.post(`${this.baseURL}/login`,login)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {

         errorMessage = errorRes.error.error[0];
         console.log("if "+errorMessage);
        // return throwError(errorMessage);
        }else if(typeof errorRes.error === "object"){
          errorMessage = "An Error Occured . Try again later";
        }
         else {
          errorMessage = errorRes.error;
          console.log("else"+errorMessage);
        }
        return throwError(errorMessage);
      })

    );
  }

  // signup(signup:Signup): Observable<Object>{
  //   return this.httpClient.post(`${this.baseURL}/signup`,signup);
  // }
  // signup(signup:Signup): Observable<Object>{
  //   return this.httpClient.post(`${this.baseURL}/signup`,signup);
  // }

  //  authenticate(loginData : LoginModel):boolean{
  //   if(this.checkCredetials(loginData)){
  //     this.isAuthenticated = true;
  //     this.isNotAuthenticated =  false;
  //     console.log(this.isAuthenticated);
  //     this.router.navigate(['/home']);
  //     return this.isAuthenticated;
  //   }
  //   this.isAuthenticated = false;
  //   console.log(this.isAuthenticated);
  //   return this.isAuthenticated;
  // }

  // private checkCredetials(loginData:LoginModel):boolean{
  //   return this.checkEmail(loginData.getEmail())&&this.checkPassword(loginData.getPassword());
  // }

  // private checkEmail(email:string):boolean{
  //   return email === this.mockedUser.getEmail();

  // }

  // private checkPassword(password:string):boolean{
  //   return password === this.mockedUser.getPassword();
  // }

  logout(){
    sessionStorage.clear();
    localStorage.clear();
    this.sessionService.isAuthenticated = false;
    this.sessionService.isNotAuthenticated =  true;
    Swal.fire("Logged Out Successfully","","success");
    setTimeout(() => {
      window.location.reload();
    }, 40);
    this.router.navigate([""]);

  }

}
