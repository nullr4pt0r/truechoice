import { Component, OnInit } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { SearchvehicleService } from '../../service/searchvehicle/searchvehicle.service';
import { CurrencyPipe } from '@angular/common';
import { registerLocaleData } from '@angular/common';
import localeIn from '@angular/common/locales/hi';
import { Router } from '../../../../node_modules/@angular/router';
import { SessionService } from '../../service/authentication/session.service';
// import { Math } from 'core-js';
import Swal from 'sweetalert2';
import { response } from '../../../../node_modules/@types/express';
import { MakerserviceService } from '../../service/vehicleservices/makerservice.service';
import { Makers } from '../../model/makers';
@Component({
  selector: 'app-searchvehicle',
  templateUrl: './searchvehicle.component.html',
  styleUrls: ['./searchvehicle.component.scss']
})
export class SearchvehicleComponent implements OnInit {
showNav : boolean = false;
models:any;
years:any;
makerData !: any;
maker !: string;
model !: string;
kms !: string;
owner !: string;
year !: string;
finance !: string;
showContent !: boolean;
filterCriteria: string = "";
page:number = 0;
query:any="?";
lastpage!:number;

 filterPage : number = 0;

 filteredVehicles : any;
constructor(private searchService:SearchvehicleService, private vehicleService:MakerserviceService ,private router:Router, private sessionService:SessionService){

}

ngOnInit():void{
  registerLocaleData(localeIn, 'hi');
  this.searchVehicle(this.query);
  this.getMaker();
  this.getModel();
  this.getYear();
}
ngViewAfterInit(){
  if(this.sessionService.isAuthenticated){
    this.showNav = true;
  }
}
details(id:number){
  if(this.sessionService.isNotAuthenticated){
    this.router.navigate(['/login']);
  }else{
  this.router.navigate(["/vehicle/",id]);
}
}

reset(){

    this.maker = 'undefined';
    this.model = 'undefined';
    this.year = 'undefined';
    this.kms = 'undefined';
    this.owner = 'undefined';
    this.finance = 'undefined';
    this.query = '?';
    this.searchVehicle(this.query);
}
next(){

  if(this.page < this.lastpage-1){
     this.page++;
     this.search();
  }
}
previous(){
  if(this.page > 0){
     this.page--;
     this.search();
  }
}

search(){
  this.showContent = false;
  let count:number = 0;
  console.log(this.maker,this.model,this.kms,this.owner,this.year,this.finance);
  this.query = '?';
  if(this.maker && this.maker != '' &&this.maker != 'undefined'){
    count++;
    this.query += `maker=${this.maker}`;
  }
  if(this.model && this.model != ''&&this.model != 'undefined'){
    count++;
    this.query += `&model=${this.model}`;
  }
  if(this.kms && this.kms != ''&&this.kms != 'undefined'){
    count++;
    this.query += `&kms=${this.kms}`;
  }
  if(this.owner && this.owner != ''&&this.owner != 'undefined'){
    count++;
    this.query += `&owner=${this.owner}`;
  }
  if(this.year && this.year != ''&&this.year != 'undefined'){
    count++;
    this.query += `&year=${this.year}`;
  }
  if(this.finance && this.finance != ''&&this.finance != 'undefined'){
    count++;
    this.query += `&finance=${this.finance}`;
  }

//  this.query += `maker=${this.maker}&model=${this.model}&year=${this.year}&kms=${this.kms}&owner=${this.owner}&finance=${this.finance}`;
  console.log(this.query);
  if(count > 0){
    this.page = 0;
  }
  this.query+= `&page=${this.page}`;
  this.searchVehicle(this.query);
}


updateFilterCriteria() {
  this.filterCriteria = "";
  if (this.maker && this.maker != ''&&this.maker != 'undefined') {
    this.filterCriteria += "Maker: " + this.maker + " ";
  }
  if (this.model && this.model != ''&&this.model != 'undefined') {
    this.filterCriteria += "Model: " + this.model + " ";
  }
  if (this.year && this.year != ''&&this.year != 'undefined') {
    this.filterCriteria += "Year: " + this.year + " ";
  }
  if (this.finance && this.finance != ''&&this.finance != 'undefined') {
    this.filterCriteria += "Finance: " + this.finance + " ";
  }
  if (this.owner && this.owner != ''&&this.owner != 'undefined') {
    this.filterCriteria += "Owner: " + this.owner + " ";
  }
  if (this.kms && this.kms != ''&&this.kms != 'undefined') {
    this.filterCriteria += "Kms: " + this.kms + " ";
  }
  console.log(this.filterCriteria);
}


  searchVehicle(query:any){

      this.searchService.searchVehicle(query).subscribe(response => {

        console.log(response);
        this.filteredVehicles = response;
        console.log(this.filteredVehicles);
        console.log(this.filteredVehicles.body.totalRecords);
        console.log(this.filteredVehicles.body.pageRecords);
        console.log(this.filteredVehicles.body);
        if(this.filteredVehicles.body != null){
          this.showContent = false;

          this.lastpage = Math.ceil(this.filteredVehicles.body.totalRecords/this.filteredVehicles.body.pageRecords);

        }
        console.log(response);
        if(this.filteredVehicles.statusCodeValue == 404){
          this.filterCriteria = "";
          this.showContent = true;
          console.log("check condition"+this.showContent);
          // Swal.fire("Cars not found !");
        }

      },
      errorMessage => Swal.fire("Cars not found !"));
  }

  getModel(){
    this.searchService.getModel().subscribe(response =>{
      this.models = response;
      console.log(this.models);
    });
  }

  getYear(){
    this.searchService.getYear().subscribe(response =>{
      this.years = response;
      console.log(this.years);
    });
  }

  getMaker(){
    this.searchService.getMaker().subscribe(response =>{
      this.makerData = response;
      console.log(this.makerData);
    });
  }

}
