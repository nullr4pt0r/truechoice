export class DealRecord {
    dealId!: number;

    sellerQuote ?: number;
    finalQuote?: number;
    vehicleId!: number;
    vehicleRegno!: string;
    vehicleKms ?: string;
    maker!: string;
    model!: string;
    seller!: string;
    variant!:string;
     sellerPhone!: string;
    buyer !: string;
    buyerPhone !: string;
    status!: string;
    createdAt!: string;
    buyerLocation !: string;
    sellerLocation !: string;
    buyerQuote ?: number;
    }