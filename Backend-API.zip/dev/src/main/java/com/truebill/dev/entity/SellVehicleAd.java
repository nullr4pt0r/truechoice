package com.truebill.dev.entity;

import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "sellvehicle" , uniqueConstraints = @UniqueConstraint(columnNames = {"vehicleRegno","sellerId"}))
public class SellVehicleAd {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long vehicleId;
    @NotEmpty(message = "Vehicle RegNo  Should not be Null")
    @Column(nullable = false)
    private String vehicleRegno;
    @ManyToOne
    @JoinColumn(name = "sellerId", referencedColumnName = "userId")
    private Users seller;
    @ManyToOne
    @JoinColumn(name = "modelId",referencedColumnName = "modelId")
    private VehicleModel model;

    @NotEmpty(message = "Vehicle Kms Should not be Null")
    @Column(nullable = false)
    private String vehicleKms;
    @NotEmpty(message = "Vehicle Owner count Should not be Null")
    @Column(nullable = false)
    private String vehicleOwnercount;
    @NotEmpty(message = " Vehicle Finance Should not be Null")
    @Column(nullable = false)
    private String vehicleFinance;
    @NotNull(message = "Vehicle Price should not be null")
    @DecimalMin(value = "0.0",message = " Vehicle Price Should not be less than 0.0")
    @Column(nullable = false)
    private double vehiclePrice;

//    status {1,2,3,4} => {published,unpublished,sold,deleted}
    private short status = 1;

    @Column(length = 512)
    private  String comments;

    @CreationTimestamp
    @Column(name = "created_At", nullable = false,updatable = false)
    private Date createdAt;

    @UpdateTimestamp
    @Column(name = "updated_At")
    private Date updatedAt;

    private long getUserId(){
        return seller.getUserId();
    }

    private long getModelId(){
        return model.getModelId();
    }

    private void setUserId(long userId){
        seller.setUserId(userId);
    }

    private void setModelId(long modelId){
       model.setModelId(modelId);
    }


//    public SellVehicleAd() {
//    }

//    public SellVehicleAd(long vehicleId, String vehicleRegno, Users seller, VehicleModel model, String vehicleKms, String vehicleOwnercount, String vehicleFinance, String vehiclePrice, String status, String comments, Date createdAt, Date updatedAt) {
//        this.vehicleId = vehicleId;
//        this.vehicleRegno = vehicleRegno;
//        this.seller = seller;
//        this.model = model;
//        this.vehicleKms = vehicleKms;
//        this.vehicleOwnercount = vehicleOwnercount;
//        this.vehicleFinance = vehicleFinance;
//        this.vehiclePrice = vehiclePrice;
//        this.status = status;
//        this.comments = comments;
//        this.createdAt = createdAt;
//        this.updatedAt = updatedAt;
//    }
}
