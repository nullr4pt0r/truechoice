import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
// import { LoginModel } from '../../model/login';
import { Router } from '@angular/router';
import {SessionService} from '../authentication/session.service';
import {Observable,throwError} from 'rxjs';
import {catchError} from 'rxjs/operators';
import { Makers } from '../../model/makers';
@Injectable({
  providedIn: 'root'
})
export class MakerserviceService {

  private baseURL = "http://localhost:9876/api/v1/vehicle";

  constructor(private httpClient:HttpClient, private sessionService:SessionService, private router:Router) { }

  getMakers():Observable<object>{
    return this.httpClient.get<Makers[]>(`${this.baseURL}/makers`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }



  getModelByMakers(id:number):Observable<object>{
    return this.httpClient.get<object[]>(`${this.baseURL}/maker/${id}/model`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }


}
