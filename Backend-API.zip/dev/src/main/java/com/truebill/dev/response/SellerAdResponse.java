package com.truebill.dev.response;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class SellerAdResponse {
    private long vehicleId;
    private String vehicleRegno;
    private String model;
    private String maker;
    private String comments;
    private String status;
    private String variant;
    private String year;
    private String vehicleKms;
    private String vehicleFinance;
    private String vehicleOwnercount;
    private String createdAt;
    private String updatedAt;
    private double vehiclePrice;
    private long modelId;
    private long totalRecords;
    private long pageRecords;

}
