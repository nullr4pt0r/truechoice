package com.truebill.dev.ServiceTest;

import com.truebill.dev.DTO.Login;
import com.truebill.dev.DTO.ValidUser;
import com.truebill.dev.config.PasswordEncoderConfig;
import com.truebill.dev.entity.Users;
import com.truebill.dev.repository.UserRepository;
import com.truebill.dev.request.LoginData;
import com.truebill.dev.service.UsersService;
import com.truebill.dev.service.UsersServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {
    @InjectMocks
    private UsersServiceImpl userService;
    @Mock
    private UserRepository userRepo;

    @Mock
    private PasswordEncoderConfig passwordEncoder;

    private Login login;
    private ValidUser valid;
    @BeforeEach
    void init(){
        login = new Login("johnadams@gmail.com","John@123");
//        valid = new ValidUser(1L,"johnadams","John Adams","chennai","user","123456789");
        valid = new ValidUser();
    }
    @Test
    @DisplayName("Login When User Credentials are correct")
    void Login(){
        //still learning
        String hashedPassword = "$2a$10$TvT.C.bKjJHnlS2cUy3LaOfnLn72Gd6zKPOlRZFFnfDG6E68KFzC6";
        when(userRepo.findPasswordByEmail(login.getEmail())).thenReturn(hashedPassword);
        when(passwordEncoder.passwordEncoder().matches(login.getPassword(),hashedPassword)).thenReturn(true);

        Users user = new Users(1,"John Adam","johnadams@gmail.com","johnadams","John@123","1234567890","Chennai","user");

        when(userRepo.findByEmailAndPassword(login.getEmail(),login.getPassword())).thenReturn(Optional.of(user));

        when(userService.VerifyUser(login)).thenReturn(ResponseEntity.ok(valid));
        ResponseEntity response = userService.VerifyUser(login);
        assertEquals(HttpStatus.OK,response.getStatusCode());
        assertEquals(valid,response.getBody());
    }
}
