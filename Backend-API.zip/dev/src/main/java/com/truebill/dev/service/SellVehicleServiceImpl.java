package com.truebill.dev.service;



import com.truebill.dev.controller.SellerController;
import com.truebill.dev.entity.SellVehicleAd;
import com.truebill.dev.entity.Users;
import com.truebill.dev.entity.VehicleModel;
import com.truebill.dev.exception.NotFoundException;
import com.truebill.dev.repository.SellVehicleRepository;
import com.truebill.dev.repository.UserRepository;
import com.truebill.dev.repository.VehicleModelRepository;
import com.truebill.dev.request.SellVehicleAdRequest;
import com.truebill.dev.response.SellerAdResponse;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class SellVehicleServiceImpl implements  SellVehicleService {
    Logger logger = LoggerFactory.getLogger(SellerController.class);
    @Autowired
    private SellVehicleRepository sellvehiclerepo;


    @Autowired
    private UserRepository userRepo;

    @Autowired
    private VehicleModelRepository modelRepo;

   private ModelMapper modelmapper = new ModelMapper();

    static String statusToString(short status){
        if(status == 1){
            return "PUBLISHED";
        }
        else if(status == 2){
            return "UNPUBLISHED";
        }
        else if(status == 3){
            return "SOLD";
        }
        else if(status == 4){
            return "DELETED";
        }
        else {
            return "Invalid Status Code";
        }
    }


    public ResponseEntity createAd(SellVehicleAdRequest vehicle) {
        logger.info("Ad creation");

        logger.info("Vehicle ad request data :" + vehicle.getVehicleFinance());
        logger.info("vehicle data :" + vehicle.getSellerId());
        logger.info("vehicle data :" + vehicle.getVehicleRegno());
        logger.info("vehicle data :" + vehicle.getVehiclePrice());
        logger.info("vehicle data :" + vehicle.getVehicleKms());
        logger.info(vehicle.getVehicleRegno(), vehicle.getVehicleFinance(), vehicle.getVehiclePrice());

        logger.info("Vehicle user id : " + vehicle.getSellerId());

        Users users = userRepo.findByUserId(vehicle.getSellerId()).orElseThrow(() -> new NotFoundException("Invalid Seller Id"));
        VehicleModel model = modelRepo.findById(vehicle.getModelId()).orElseThrow(() -> new NotFoundException("Invalid Model Id"));
//        if (!users.isPresent() || !model.isPresent()) {
//            return ResponseEntity.status(200).body("Invalid seller ID or model ID");
//        }
//        Users user1 = users.get();
        Optional<SellVehicleAd> existingAd;
//        = sellvehiclerepo.findByRegNoAndSellerId(vehicle.getVehicleRegNo(), users.getUserId());//orElseThrow(()-> new NotFoundException("Exisitng ad not found"));

        //SellVehicleAd getAd = existingAd.get();
//        if (existingAd.isPresent() && existingAd.get().getStatus().equals("Created")) {
//            return ResponseEntity.status(HttpStatus.FOUND).body("AD already posted with id : "+existingAd.get().getVehicleId());
//        }
        if (vehicle.getVehicleRegno() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"error\": \"Missing Required parameter Vehicle Reg Number\"}");
        } else if (!vehicle.getVehicleRegno().matches("[A-Z]{2}[0-9]{1,2}(?:[A-Z])?(?:[A-Z]*)?[0-9]{1,4}")) {
            // Return a response with a status code of 400 (Bad Request) and a meaningful error message
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"error\": \"Invalid vehicle registration number format\"}");
        }
//        Long count = sellvehiclerepo.countByVehicleRegnoAndStatus(vehicle.getVehicleRegno(),(short)1);
        existingAd = sellvehiclerepo.findTopByVehicleRegnoOrderByUpdatedAtDesc(vehicle.getVehicleRegno());
        logger.info("Sellvehicle ad : " + existingAd.toString());
        if (existingAd.isPresent() && (existingAd.get().getStatus() == 1 || existingAd.get().getStatus() == 2)) {
            logger.info("existing ad is present and status is published");

            if (existingAd.get().getSeller().getUserId() == vehicle.getSellerId()) {
                logger.info("same user id");
                logger.error("ad slready posted by same user id " + existingAd.get().getSeller().getUserId());
//                return ResponseEntity.status(200).body("AD already posted with id : "+existingAd.get().getVehicleId());
                return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("{\"error\": \"AD already posted with same Reg no by you with ad id: " + existingAd.get().getVehicleId() + "\"}");

            } else {
                logger.info("different user");
                logger.error("ad posted by different user");
                return ResponseEntity.status(HttpStatus.CONFLICT).body("{\"error\":\"Another Ad is posted with same Reg No by other seller.Please contact support team !\"}");
            }
        }
        int existcount =0, newcount=0;
        if(existingAd.isPresent()){
        logger.info(existingAd.get().getVehicleOwnercount());
        logger.info(vehicle.getVehicleOwnercount());

        if ((existingAd.get().getVehicleOwnercount().equals("4+")) && vehicle.getVehicleOwnercount().equals("4+")) {
            existcount = 5;
            newcount = 6;
        } else if (existingAd.get().getVehicleOwnercount().equals("4+")) {
            existcount = 5;
            newcount = Integer.parseInt(vehicle.getVehicleOwnercount());
        } else if (vehicle.getVehicleOwnercount().equals("4+")) {
            newcount = 6;
            existcount = Integer.parseInt(existingAd.get().getVehicleOwnercount());
        } else {
            newcount = Integer.parseInt(vehicle.getVehicleOwnercount());
            existcount = Integer.parseInt(existingAd.get().getVehicleOwnercount());
        }
   }

        if (existingAd.isPresent() && (existingAd.get().getStatus() == 3)) {
            logger.info("Ad is once sold");
            logger.info("seller id now : "+vehicle.getSellerId());
            logger.info("existing seller id:"+existingAd.get().getSeller().getUserId());
            if (existingAd.get().getSeller().getUserId() == vehicle.getSellerId()) {
                logger.info("same user id");
                logger.error("ad already posted by same user id " + existingAd.get().getSeller().getUserId());
//                return ResponseEntity.status(200).body("AD already posted with id : "+existingAd.get().getVehicleId());
                return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("{\"error\": \"AD already posted with same Reg no by you with ad id: " + existingAd.get().getVehicleId() + "\"}");

            }
            if (existingAd.get().getModel().getModelId() != vehicle.getModelId()) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body("{\"error\":\"Car Maker and Model Data is conflict with previously Purchased Car\"}");

            }
            else if (existcount >= newcount) {
                logger.info(String.valueOf(existcount > newcount));
                return ResponseEntity.status(HttpStatus.CONFLICT).body("{\"error\":\"Car Owner Count is conflict with previously Purchased Car\"}");
            }


        }
            logger.info("going to insert");
            SellVehicleAd newAd = new SellVehicleAd();
            newAd.setVehicleRegno(vehicle.getVehicleRegno());
            newAd.setVehicleFinance(vehicle.getVehicleFinance());
            newAd.setVehiclePrice(vehicle.getVehiclePrice());
            newAd.setComments(vehicle.getComments());
            newAd.setVehicleKms(vehicle.getVehicleKms());
            newAd.setVehicleOwnercount(vehicle.getVehicleOwnercount());
            newAd.setModel(model);
            newAd.setSeller(users);

            sellvehiclerepo.save(newAd);
            return ResponseEntity.status(201).body("{\"message\":\" Ad Created Successfully\"}");
        }


    @Override
    public ResponseEntity findAdById(long vid) {

        Optional<SellVehicleAd> ad = sellvehiclerepo.findByvehicleId(vid);
        if(ad.isEmpty()){
            return  ResponseEntity.status(404).body("{\"error\":\"Ad not found\"}");
        }
        else{
            SellerAdResponse response = modelmapper.map(ad.get(),SellerAdResponse.class);
            response.setStatus(statusToString(ad.get().getStatus()));
            response.setMaker(ad.get().getModel().getMaker().getMaker());
            response.setVariant(ad.get().getModel().getVariant());
            response.setYear(ad.get().getModel().getYear());
            response.setModelId(ad.get().getModel().getModelId());
            return ResponseEntity.status(200).body(response);
        }

    }

    @Override
    public ResponseEntity findByVIN(String vin) {
        return ResponseEntity.status(200).body(sellvehiclerepo.findTopByVehicleRegnoOrderByUpdatedAtDesc(vin));
    }

    @Override
    public ResponseEntity findAllAuto(long uid, @PageableDefault(value = 100) Pageable pageable) {

        List<SellerAdResponse> responseAd = new ArrayList<>();
        Page<SellVehicleAd> ad = sellvehiclerepo.findBySellerUserId(uid,pageable);
        for(SellVehicleAd a : ad.getContent()){
          SellerAdResponse  response = modelmapper.map(a,SellerAdResponse.class);
            response.setStatus(statusToString(a.getStatus()));
            response.setMaker(a.getModel().getMaker().getMaker());
            response.setVariant(a.getModel().getVariant());
            response.setYear(a.getModel().getYear());
            responseAd.add(response);
        }

        logger.info(responseAd.toString());
        return ResponseEntity.status(200).body(responseAd);
    }


    public ResponseEntity updateSellVehicleAdBySellerIdAndVehicleId( long vehicleId, SellVehicleAdRequest updateAd){
        Optional<SellVehicleAd> ad = sellvehiclerepo.findByvehicleId(vehicleId);
        if(ad.isEmpty()){
            return ResponseEntity.status(404).body("{\"error\":\"Ad not found\"}");
        }
        else if(ad.get().getSeller().getUserId() != updateAd.getSellerId()){
            return  ResponseEntity.status(HttpStatus.FORBIDDEN).body("{\"error\":\"User Id Conflict\"}");
        }

        SellVehicleAd newAd =  ad.get();
        if(newAd.getStatus() == 3 || updateAd.getStatus() >2 && updateAd.getStatus() <1){
            return  ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body("{\"error\":\"Status is not applicable\"}");
        }
        newAd.setVehicleOwnercount(updateAd.getVehicleOwnercount());
        newAd.setVehicleKms(updateAd.getVehicleKms());
        newAd.setVehicleFinance(updateAd.getVehicleFinance());
        newAd.setVehiclePrice(updateAd.getVehiclePrice());
        newAd.setComments(updateAd.getComments());
        newAd.setVehicleRegno(updateAd.getVehicleRegno());
        newAd.setStatus(updateAd.getStatus());


        newAd = sellvehiclerepo.save(newAd);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(newAd);
    }

    @Override
    public ResponseEntity findAllAdByUser(long uid) {
        return ResponseEntity.status(200).body(sellvehiclerepo.countVehicleIdBySellerUserId(uid));
    }
}
