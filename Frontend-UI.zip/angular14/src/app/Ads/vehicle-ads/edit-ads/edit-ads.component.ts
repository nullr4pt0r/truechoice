import { Component, OnInit } from '@angular/core';
import { User } from '../../../model/user';
import { LocationsService } from '../../../service/location/locations.service';
import {Ad} from '../../../model/ad';
import {Makers} from '../../../model/makers';
import { MakerserviceService } from '../../../service/vehicleservices/makerservice.service';
import { Model } from '../../../model/model';
import { Set } from 'typescript';
import { AdcrudService } from '../../../service/adservices/adcrud.service';
import { Router, ActivatedRoute } from '../../../../../node_modules/@angular/router';
import { UserdataService } from '../../../service/userdata/userdata.service';
import { Adcrud } from '../../../model/Adcrudmodel/adcrud';
import { UpdateAd } from '../../../model/Adcrudmodel/update-ad';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-edit-ads',
  templateUrl: './edit-ads.component.html',
  styleUrls: ['./edit-ads.component.scss']
})
export class EditAdsComponent implements OnInit {

  disable:boolean = false;
  ad!:Adcrud;
  adId !: number;
  modifyAd !: UpdateAd;
  // newAd : Ad = new Ad();
  data : any;
  sellerId !: number;
  adResponse : any;
  constructor(private userdataservice:UserdataService,private route:ActivatedRoute, private adCrudService:AdcrudService,private router:Router,private vehicleService:MakerserviceService,private adcrudService:AdcrudService) { }

  ngOnInit(): void {
    this.modifyAd = {} as UpdateAd;
    this.data = this.userdataservice.getData();
     this.modifyAd.sellerId = this.data.userid;
    this.adId = this.route.snapshot.params['id'];
    console.log(this.adId);
    this.adCrudService.getAdById(this.adId).subscribe(response => {
      this.ad = response;
      console.log("from init");
      console.log(this.ad);
      console.log("status"+this.ad.status);
      this.modifyAd.modelId = this.ad.modelId;
      if(this.ad.status === "SOLD"){
        console.log("status"+this.ad.status);
        this.disable = !this.disable;
        console.log("disable value"+this.disable);
      }

    });
    console.log("setData call");

    console.log(this.ad);

  }

  onSubmit(){
    console.log(this.ad);
    console.log(this.modifyAd);

    this.setAdData(this.ad);
    console.log(this.modifyAd);
    this.adCrudService.modifyAdById(this.adId,this.modifyAd).subscribe(response =>{
      this.router.navigate(['/viewad',this.adId]);
    },error =>{
      Swal.fire("Error",error.error,"error");
    })
  }

  setAdData(ad:Adcrud){

    if(ad.status == "PUBLISHED"){
      this.modifyAd.status = 1;
    }else if(ad.status == "UNPUBLISHED"){
      this.modifyAd.status = 2;
    }

    this.modifyAd.vehicleRegno = this.ad.vehicleRegno;
    this.modifyAd.vehicleKms = this.ad.vehicleKms;
    this.modifyAd.vehiclePrice = this.ad.vehiclePrice;
    this.modifyAd.vehicleOwnercount = this.ad.vehicleOwnercount;
    this.modifyAd.vehicleFinance = this.ad.vehicleFinance;
    this.modifyAd.comments = this.ad.comments;
    this.modifyAd.vehicleId = this.ad.vehicleId;
    console.log(this.ad.modelId);

  }






}
