import { TestBed } from '@angular/core/testing';

import { AdcrudService } from './adcrud.service';

describe('AdcrudService', () => {
  let service: AdcrudService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdcrudService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
