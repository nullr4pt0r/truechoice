export class Ad {
    vehicleRegno !: string;
    vehicleKms !: string;
    vehiclePrice !:number;
    vehicleOwnercount !: string;
    vehicleFinance !: string;
    comments ?: string;
    modelId !: number;
    sellerId !: number;

}
