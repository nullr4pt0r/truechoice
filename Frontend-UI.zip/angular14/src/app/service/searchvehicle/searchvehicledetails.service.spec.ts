import { TestBed } from '@angular/core/testing';

import { SearchvehicledetailsService } from './searchvehicledetails.service';

describe('SearchvehicledetailsService', () => {
  let service: SearchvehicledetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SearchvehicledetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
