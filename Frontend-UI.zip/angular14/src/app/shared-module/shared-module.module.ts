import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SessionService } from '../service/authentication/session.service';
import { SideNavComponent } from '../nav-bars/nav-bars/side-nav/side-nav.component';



@NgModule({
  declarations: [SideNavComponent],
  imports: [
    CommonModule
  ],
  providers:[SessionService]
})
export class SharedModuleModule { }
