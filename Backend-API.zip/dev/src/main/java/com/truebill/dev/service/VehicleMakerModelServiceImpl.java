package com.truebill.dev.service;

import com.truebill.dev.entity.VehicleMaker;
import com.truebill.dev.entity.VehicleModel;
import com.truebill.dev.repository.VehicleMakerRepository;
import com.truebill.dev.repository.VehicleModelRepository;
import com.truebill.dev.request.NewMaker;
import com.truebill.dev.request.NewModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class VehicleMakerModelServiceImpl implements  VehicleMakerModelService{

    Logger logger = LoggerFactory.getLogger(VehicleMakerModelServiceImpl.class);

    @Autowired
    private VehicleMakerRepository makerRepo;
    @Autowired
    private VehicleModelRepository modelRepo;


    @Override
    public ResponseEntity addNewMaker(NewMaker maker) {
        VehicleMaker maker1 =  new VehicleMaker();
        maker1.setMaker(maker.getMaker());
        maker1.setVehicleType(maker.getVehicleType());
        return ResponseEntity.status(200).body(makerRepo.save(maker1));
    }

    @Override
    public ResponseEntity addNewModel(NewModel model) {
        VehicleModel model1 = new VehicleModel();
        VehicleMaker maker = new VehicleMaker();
        maker = makerRepo.findById(model.getMakerId()).get();
        if(maker == null){
            return ResponseEntity.status(404).body("Maker not found");
        }
        model1.setMaker(maker);
        model1.setYear(model.getYear());
        model1.setVariant(model.getVariant());
        model1.setModel(model.getModel());
        return ResponseEntity.status(200).body(modelRepo.save(model1));
    }
}
