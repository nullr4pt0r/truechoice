package com.truebill.dev.repository;

import com.truebill.dev.entity.SellVehicleAd;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import java.util.List;
import java.util.Optional;

@Repository
public interface SellVehicleRepository extends JpaRepository<SellVehicleAd,Long> {
    boolean existsByVehicleRegnoAndSeller(String regno,Long sid);
    boolean existsByVehicleRegno(String regno);

//    @Query("SELECT CASE WHEN COUNT(*) > 0 THEN 'true' ELSE 'false' END " +
//            "FROM truebilldev.sellvehicle WHERE vehicle_regno = ':regno' AND seller_id = :userId")
//    boolean existsByVehicleRegnoAndUserId(String regno,
//                                    long userId);


    @Query(value = "SELECT * FROM sellvehicle WHERE vehicle_regno = :regNo AND seller_id = :sellerId", nativeQuery = true)
    Optional<SellVehicleAd> findByRegNoAndSellerId(String regNo, Long sellerId);

    Optional<SellVehicleAd> findByVehicleRegnoAndSeller(long regno, Long sid);

    Optional<SellVehicleAd> findByVehicleRegno(String regno);

    Optional<SellVehicleAd> findTopByVehicleRegnoOrderByUpdatedAtDesc(String regno);
//    Optional<SellVehicleAd> findTopByVehicleRegnoOrderByUpdatedAtDesc(String regno);



    long countByVehicleRegnoAndStatus(String regno,short status);

//    @Query("SELECT * FROM sellvehicle WHERE vehicle_regno = :regNo")
//    List<SellVehicleAd> findByVehicleRegnoAsList(String regno);


    Optional<SellVehicleAd> findByvehicleId(long vid);

    Page<SellVehicleAd> findBySellerUserId(long sid, Pageable pageable);

//    @Query("SELECT v FROM SellVehicleAd v WHERE " +
//            "(:model is null or v.model.model = :model)"+
//            "(:vehicleVariant is null or v.model.variant = :vehicleVariant) and " +
//            "(:vehicleMaker is null or v.model.maker = :vehicleMaker) and " +
//            "(:vehicleKms is null or v.vehicleKms = :vehicleKms) and " +
//            "(:vehicleOwnercount is null or v.vehicleOwnercount = :vehicleOwnercount) and " +
//            "(:vehicleFinance is null or v.vehicleFinance = :vehicleFinance) and " +
//            "(:vehiclePrice is null or v.vehiclePrice <= :vehiclePrice) and" +
//            " (v.status = 1)")
//    Page<SellVehicleAd> findAllBySearch(String vehicleMaker, String model , String vehicleVariant, String vehicleKms,String vehicleOwnercount,
//                                        String vehicleFinance, String vehiclePrice, Pageable pageable);

//    @Query("SELECT c FROM SellVehicleAd c WHERE (:maker is null or c.model.maker.maker =:maker) AND (:model is null or c.model.model = :model)" )
    @Query("SELECT c FROM SellVehicleAd c WHERE (:maker is null or :maker = '' or c.model.maker.maker =:maker) " +
            "AND (:model is null or :model = '' or c.model.model = :model)  AND " +
            "(:year is null or :year='' or c.model.year =:year) AND" +
            "(:kms is null or :kms='' or c.vehicleKms =:kms) AND " +
            "(:owner is null or :owner= '' or c.vehicleOwnercount =:owner ) AND " +
             "(:finance is null or :finance = '' or c.vehicleFinance like :finance)  AND " +
            "(c.status = 1) ORDER BY c.createdAt Desc ")
    Page<SellVehicleAd> findAllByMakerModel (String maker,String model,String owner, String finance, String kms, String year,Pageable pageable);
    @Query("SELECT COUNT(c) FROM SellVehicleAd c WHERE (:maker is null or :maker = '' or c.model.maker.maker =:maker) AND (:model is null or :model = '' or c.model.model = :model)  AND (:year is null or :year='' or c.model.year =:year) AND(:kms is null or :kms='' or c.vehicleKms =:kms) AND (:owner is null or :owner= '' or c.vehicleOwnercount =:owner ) AND (:finance is null or :finance = '' or c.vehicleFinance = :finance) AND (c.status = 1) AND (c.seller.userId != :userId)")
    long countByMakerModel (String maker,String model,String owner, String finance, String kms, String year,long userId);

    long countVehicleIdBySellerUserId(long uid);

}
