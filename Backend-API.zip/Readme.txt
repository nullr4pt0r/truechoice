Backend Technology

Lang : Java 11
IDE : STS 
Service : Rest API 

Build Tool : Maven
ORM : Hibernate
Database : MySQl