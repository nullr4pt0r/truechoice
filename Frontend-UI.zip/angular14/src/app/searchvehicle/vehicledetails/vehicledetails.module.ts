import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VehicledetailsComponent } from './vehicledetails/vehicledetails.component';
import { FormsModule } from '../../../../node_modules/@angular/forms';
import { NgxUiLoaderModule } from '../../../../node_modules/ngx-ui-loader';
import { NavBarsModule } from '../../nav-bars/nav-bars/nav-bars.module';



@NgModule({
  declarations: [
    VehicledetailsComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    NgxUiLoaderModule,
    NavBarsModule
  ],
  exports:[
    VehicledetailsComponent
  ]
})
export class VehicledetailsModule { }
