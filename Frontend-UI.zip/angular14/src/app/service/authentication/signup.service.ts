import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Signup} from '../../model/signup';
// import { Router } from '@angular/router';
// import {SessionService} from '../authentication/session.service';
import {Observable,throwError} from 'rxjs';
import {catchError} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SignupService {
  private baseURL = "http://localhost:9876/api/v1";

  constructor(private httpClient:HttpClient) { }

  signup(signup:Signup) : Observable<Object>{
    return this.httpClient.post(`${this.baseURL}/signup`,signup)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }
}
