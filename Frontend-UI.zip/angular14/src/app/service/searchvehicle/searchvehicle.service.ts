import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {catchError} from 'rxjs/operators';
import {Observable,throwError} from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class SearchvehicleService {

  private baseURL = "http://localhost:9876/api/v1";

  constructor(private httpClient:HttpClient) { }

  searchVehicle(query:string):Observable<object>{
    // return this.httpClient.get<any[]>(`${this.baseURL}/search/auto?maker=${maker}&model=${model}&kms=${kms}&year=${year}&owner=${owner}&finance=${finance}`)
    return this.httpClient.get<any[]>(`${this.baseURL}/search/auto${query}`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {

         errorMessage = errorRes.error.error[0];
         console.log("if "+errorMessage);
        // return throwError(errorMessage);
        }else if(typeof errorRes.error === "object"){
          errorMessage = "An Error Occured . Try again later";
        }
         else {
          errorMessage = errorRes.error;
          console.log("else"+errorMessage);
        }
        return throwError(errorMessage);
      })

    );

  }


  getModel():Observable<object>{
    return this.httpClient.get<any[]>(`${this.baseURL}/vehicle/all/model`)
  }

  getYear():Observable<object>{
    return this.httpClient.get<any[]>(`${this.baseURL}/vehicle/all/year`)
  }

  getMaker():Observable<object>{
    return this.httpClient.get<any[]>(`${this.baseURL}/vehicle/all/maker`)
  }
}
