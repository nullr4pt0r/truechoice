export class Makers {
    makerId !: number;
    maker !: string;
    vehicleType !: string;
}
