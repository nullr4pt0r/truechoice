import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '../../../../node_modules/@angular/router';
import { FetchdealdataService } from '../../service/dealService/fetchdealdata.service';
import { DealRecord } from '../../model/dealRecords/dealrecord';
import { UserdataService } from '../../service/userdata/userdata.service';
import jspdf from 'jspdf';
import  html2canvas from 'html2canvas';

@Component({
  selector: 'app-salesdata',
  templateUrl: './salesdata.component.html',
  styleUrls: ['./salesdata.component.scss']
})
export class SalesdataComponent implements OnInit {
  showContent : boolean = false;
  id!:number;
  sellerId!:number;
  saleData : any;
  dealRecord :DealRecord = new DealRecord();
  constructor(private route:ActivatedRoute, private fetchDealsService:FetchdealdataService,private userdataservice:UserdataService) { }

  ngOnInit(): void {

    this.id = this.route.snapshot.params['id'];
    console.log(this.id);
    this.sellerId = this.userdataservice.getData().userid;

    this.fetchDealsService.getDealResponseBySellerIdAndDealId(this.id,this.sellerId)
    .subscribe(response =>{
        this.saleData = response;
        this.showContent = true;
        console.log(response);
        console.log(this.saleData);
    })
  }
  downloadPDF() {
    const data = document.getElementById('invoice-content')!;
    html2canvas(data)!.then(canvas => {
      const imgWidth = 208;
      const pageHeight = 200;
      const imgHeight = canvas.height * imgWidth / canvas.width;
      const heightLeft = imgHeight;
      const contentDataURL = canvas.toDataURL('image/png');
      const pdf = new jspdf('p', 'mm', 'a4');
      pdf.addImage(contentDataURL, 'PNG', 0, 0, imgWidth, imgHeight);
      pdf.save(`Invoice-${this.saleData.vehicleRegno}.pdf`);
    });
  }
}