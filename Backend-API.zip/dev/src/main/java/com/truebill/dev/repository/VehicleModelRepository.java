package com.truebill.dev.repository;

import com.truebill.dev.entity.VehicleModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.swing.text.html.Option;
import java.util.List;
import java.util.Optional;

@Repository
public interface VehicleModelRepository extends JpaRepository<VehicleModel,Long> {

    Optional<List> findByMakerMakerId(long id);

    @Query("SELECT DISTINCT m.model  FROM VehicleModel m")
    List<String> findDistinctByModel();

    @Query("SELECT DISTINCT m.year  FROM VehicleModel m ORDER BY m.year DESC")
    List<String> findDistinctByYear();
}
