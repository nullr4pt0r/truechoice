package com.truebill.dev.request;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DealRecord {
    private long vehicleId;
    private String vehicleRegno;
    private  String finalQuote;
    private long sellerId;
    private long buyerId;
    private short status;
}
