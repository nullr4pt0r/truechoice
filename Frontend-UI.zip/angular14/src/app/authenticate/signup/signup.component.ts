import { Component, OnInit } from '@angular/core';
import { Signup } from "../../model/signup";
import { FormGroup, FormControl, Validators, NgForm } from '../../../../node_modules/@angular/forms';
import {SessionService} from '../../service/authentication/session.service';
import {SignupService} from '../../service/authentication/signup.service';
import { Router } from '../../../../node_modules/@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  signup: Signup = new Signup();
  passwordinvalid!:boolean;
  isLoading:boolean = false;
  data: any;
  error:any = null;

   cities: string[] = ["Bengaluru", "Chennai", "Hyderabad", "Coimbatore", "Visakhapatnam", "Madurai", "Thiruvananthapuram",
    "Vijayawada", "Ernakulam", "Kozhikode", "Thrissur", "Kochi", "Mangaluru", "Belagavi",
    "Mysore", "Vishakapatnam", "Tiruchirappalli", "Thoothukudi", "Salem", "Tiruppur", "Erode", "Tirunelveli",
    "Kannur", "Thiruvannamalai", "Guntur", "Tirupati", "Nellore", "Anantapur", "Kadapa", "Rajahmundry",
    "Kurnool", "Tiruvallur", "Cuddalore", "Tiruvannamalai", "Vellore", "Tiruvallur", "Nagercoil",
    "Tiruchirappalli", "Thanjavur", "Tirunelveli", "Namakkal", "Vellore", "Tirupati", "Tiruchirappalli",
    "Tiruppur", "Erode", "Salem", "Thoothukudi", "Madurai", "Thanjavur", "Tirunelveli", "Namakkal", "Kannur",
    "Thiruvannamalai", "Guntur", "Tirupati", "Nellore", "Anantapur", "Kadapa", "Rajahmundry", "Kurnool",
    "Tiruvallur", "Cuddalore", "Tiruvannamalai", "Vellore", "Tiruvallur", "Nagercoil"];


  constructor(private sessionService:SessionService, private router:Router, private signupService:SignupService) {
  }

  ngOnInit(): void {
    console.log(this.passwordinvalid)
  }

  checkPassword() {
    console.log("pwd check initiate"+this.passwordinvalid)
    if(this.signup.password !== '' && this.signup.confirmPassword !== ''){
    if(this.signup.password !== this.signup.confirmPassword){
      this.passwordinvalid = true;
    }
    else{
      this.passwordinvalid = false;
    }}
    else{
      this.passwordinvalid = true;
    }
    console.log("pwd check finished"+this.passwordinvalid)
  }

  onSubmit(f:NgForm) {
    console.log(this.signup);
    this.isLoading = true;
    if (this.sessionService.checkSession()) {
      var id: any = document.getElementById("errormessage");
      id.innerHTML = "You are already login . Logout to login different account";
      this.router.navigate(['/home']);
    }
    else{
      this.createUser(this.signup,f);
    }

  }

  createUser(signupData:Signup,form:NgForm){
    this.signupService.signup(signupData).subscribe(response =>
    {
      console.log(response);
      this.data = response;
      this.sessionService.setSession(this.data);
      console.log(this.data);
      this.sessionService.isAuthenticated = true;
      this.sessionService.isNotAuthenticated = false;
      Swal.fire("Welcome to TrueChoice","","success");
      this.router.navigate(['home']);
    },
    errorMessage => {


      console.log(errorMessage);
      console.log("error");
      console.error(errorMessage);
      this.error = errorMessage;

      this.isLoading = false;

      console.log(typeof(this.error));

    });
  }


}
