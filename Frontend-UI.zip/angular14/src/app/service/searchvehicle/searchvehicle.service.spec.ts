import { TestBed } from '@angular/core/testing';

import { SearchvehicleService } from './searchvehicle.service';

describe('SearchvehicleService', () => {
  let service: SearchvehicleService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SearchvehicleService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
