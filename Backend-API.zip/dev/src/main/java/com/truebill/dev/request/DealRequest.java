package com.truebill.dev.request;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DealRequest {
    private long dealId;
    private double buyerQuote;
    private long vehicleId;
    private long buyerId;
    private short status;
}
