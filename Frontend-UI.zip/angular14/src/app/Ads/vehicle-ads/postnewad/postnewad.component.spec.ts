import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PostnewadComponent } from './postnewad.component';

describe('PostnewadComponent', () => {
  let component: PostnewadComponent;
  let fixture: ComponentFixture<PostnewadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PostnewadComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PostnewadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
