import { Adcrud } from './adcrud';

describe('Adcrud', () => {
  it('should create an instance', () => {
    expect(new Adcrud()).toBeTruthy();
  });
});
