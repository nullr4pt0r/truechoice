import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SigninComponent } from './signin/signin.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {LoginService} from '../service/authentication/login.service';
import {SessionService} from '../service/authentication/session.service';
import { RouterModule } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
// import { LoadingSpinnerComponent } from '../shared-folder/loading-spinner/loading-spinner/loading-spinner.component';
import { LoadingSpinnerModule } from '../shared-folder/loading-spinner/loading-spinner.module';
import { AlertModalModule } from '../alert-modal/alert-modal/alert-modal.module';
import { NgxUiLoaderModule } from "ngx-ui-loader";


@NgModule({
  declarations: [
    SigninComponent,
    SignupComponent,

  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    LoadingSpinnerModule,
    AlertModalModule,
    NgxUiLoaderModule
  ],
  providers: [LoginService, SessionService],
  exports:[
    SigninComponent
  ]
})
export class AuthenticateModule { }
