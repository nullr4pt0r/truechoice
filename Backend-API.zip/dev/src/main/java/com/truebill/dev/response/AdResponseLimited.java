package com.truebill.dev.response;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class AdResponseLimited {
    private long vehicleId;
    private String model;
    private String maker;
    private String comments;
    private String status;
    private String variant;
    private String year;
    private String vehicleKms;
    private String vehicleFinance;
    private String vehicleOwnercount;
    private double vehiclePrice;
    private long modelId;
    private String createdAt;
    private String updatedAt;
}
