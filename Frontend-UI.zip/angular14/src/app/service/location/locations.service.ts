import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LocationsService {

  constructor() { }

  cities: string[] = ["Bengaluru", "Chennai", "Hyderabad", "Coimbatore", "Visakhapatnam",
  "Thiruvananthapuram",
    "Vijayawada", "Ernakulam", "Kozhikode", "Thrissur", "Kochi", "Mangaluru", "Belagavi",
    "Mysore", "Vishakapatnam", "Tiruchirappalli",
    "Kannur", "Cuddalore", "Nagercoil", "Vellore",
    "Tiruppur", "Erode", "Salem", "Thoothukudi", "Madurai", "Thanjavur", "Tirunelveli", "Namakkal",
     "Guntur", "Tirupati", "Nellore", "Anantapur", "Kadapa", "Rajahmundry", "Kurnool",
    "Tiruvallur"];

    getLocation():string[]{
      return this.cities;
    }
}
