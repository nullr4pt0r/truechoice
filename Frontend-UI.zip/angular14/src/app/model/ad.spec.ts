import { Ad } from './ad';

describe('Ad', () => {
  it('should create an instance', () => {
    expect(new Ad()).toBeTruthy();
  });
});
