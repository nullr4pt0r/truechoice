import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserdataService {
  data:any;
  userData:any;

  constructor() {
    console.log();
  }
  getData(){
  this.data = sessionStorage.getItem("userJson");
  this.userData =  JSON.parse(this.data);
  console.log("From user data service "+this.userData);
  if(this.userData != null){
    return this.userData;
  }
  else{
    return null;
  }

  }

}
