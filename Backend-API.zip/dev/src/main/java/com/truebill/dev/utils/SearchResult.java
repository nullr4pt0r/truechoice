package com.truebill.dev.utils;

import com.truebill.dev.response.SellerAdResponse;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SearchResult {
    private List<SellerAdResponse> vehicles;
    private Long totalRecords;
    private  int pageRecords;
}
