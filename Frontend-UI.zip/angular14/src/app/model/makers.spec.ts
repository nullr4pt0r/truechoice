import { Makers } from './makers';

describe('Makers', () => {
  it('should create an instance', () => {
    expect(new Makers()).toBeTruthy();
  });
});
