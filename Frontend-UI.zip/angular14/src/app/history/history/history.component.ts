import { Component, OnInit } from '@angular/core';
import { Router } from '../../../../node_modules/@angular/router';
import { UserdealhistoryService } from '../../service/history/userdealhistory.service';
import { UserdataService } from '../../service/userdata/userdata.service';
import { DealRecord } from '../../model/dealRecords/dealrecord';
import { NgxUiLoaderModule } from '../../../../node_modules/ngx-ui-loader';
@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.scss']
})
export class HistoryComponent implements OnInit {

  id !: number;
  orderData !: DealRecord[];
  showContent !: boolean;
  dtOptions : DataTables.Settings = {};

  constructor(private router:Router , private historyService:UserdealhistoryService,private userdataService: UserdataService) { }


  ngOnInit(): void {
    this.id = this.userdataService.getData().userid;
    console.log(this.id);
    this.historyService.getHistoryByUserId(this.id).subscribe(response =>{
      this.orderData = response as DealRecord[];
      console.log(response);
      console.log(this.orderData);
    });
    this.dtOptions = {
      pagingType: 'full_numbers',
      // lengthMenu: [10],
      pageLength : 10,
      processing: true
    },
    setTimeout(()=>this.showContent=true, 250)
  }


  seller(id:number){
    this.router.navigate(["/sell/bill/",id]);
  }
  buyer(id:number){
    this.router.navigate(["/buy/bill/",id]);
  }

}
