package com.truebill.dev.service;

import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

public interface VehicleSearchService {

    ResponseEntity searchVehicles(String maker, String model, String owner, String finance, String kms, String year,String userid, Pageable pageable);

    ResponseEntity viewLimitedDetails(long id);




}
