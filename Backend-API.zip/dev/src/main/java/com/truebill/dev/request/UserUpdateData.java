package com.truebill.dev.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserUpdateData {
    private String fullName;
    private String email;
//    private String password;
    private String username;
    private String phoneNumber;
    private String location;
}
