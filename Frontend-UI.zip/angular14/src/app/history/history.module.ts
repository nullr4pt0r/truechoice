import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HistoryComponent } from './history/history.component';
import { NgxUiLoaderModule } from '../../../node_modules/ngx-ui-loader';
import { DataTableDirective, DataTablesModule } from '../../../node_modules/angular-datatables';
import { NavBarsModule } from '../nav-bars/nav-bars/nav-bars.module';



@NgModule({
  declarations: [
    HistoryComponent
  ],
  imports: [
    CommonModule,
    NgxUiLoaderModule,
    DataTablesModule,
    NavBarsModule
  ],
  exports:[
    HistoryComponent
  ]
})
export class HistoryModule { }
