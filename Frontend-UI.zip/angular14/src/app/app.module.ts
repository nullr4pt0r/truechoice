  import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { HomeComponent } from './service/home/home.component';
import { StatisticsComponent } from './service/statistics/statistics.component';

import { UserviewComponent } from './landing/userview/userview.component';
import { AuthenticateModule } from './authenticate/authenticate.module';
import { SessionService } from './service/authentication/session.service';
import { LoadingSpinnerModule } from './shared-folder/loading-spinner/loading-spinner.module';
// import { AlertModalComponent } from './alert-modal/alert-modal/alert-modal/alert-modal.component';
import { AlertModalModule } from './alert-modal/alert-modal/alert-modal.module';
import { NavBarsModule } from './nav-bars/nav-bars/nav-bars.module';
import { UseractionsModule } from './useractions/useractions.module';
import { VehicleAdsModule } from './Ads/vehicle-ads/vehicle-ads.module';
import { UserprofileModule } from './userprofile/userprofile.module';
import {DataTablesModule} from 'angular-datatables';
import { SearchvehicleModule } from './searchvehicle/searchvehicle.module';
import { VehicledetailsModule } from './searchvehicle/vehicledetails/vehicledetails.module';
import { SessionInterceptor } from './interceptors/session.service';
import { DealsModule } from './deals/deals.module';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { NgxUiLoaderModule,NgxUiLoaderHttpModule } from "ngx-ui-loader";
import { HistoryModule } from './history/history.module';



// import { LoadingSpinnerComponent } from './shared-folder/loading-spinner/loading-spinner/loading-spinner.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    StatisticsComponent,
    UserviewComponent,
    PagenotfoundComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HistoryModule,
    HttpClientModule,
    AuthenticateModule,
    LoadingSpinnerModule,
    AlertModalModule,
    NavBarsModule,
    UseractionsModule,
    VehicleAdsModule,
    UserprofileModule,
    DataTablesModule,
    SearchvehicleModule,
    VehicledetailsModule,
    DealsModule,
    NgxUiLoaderModule,
    NgxUiLoaderHttpModule.forRoot({
      showForeground:true,
      }),
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: SessionInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
