package com.truebill.dev.request;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class SellVehicleAdRequest {

    private String vehicleRegno;
    private long modelId;
    private String vehicleKms;
    private String VehicleOwnercount;
    private double vehiclePrice;
    private String comments;
    private long sellerId;
    private String vehicleFinance;
    private short status;

}
