import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyprofileComponent } from './myprofile/myprofile.component';
import { UserprofileService } from '../service/userprofile/userprofile.service';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';
import { FormsModule } from '../../../node_modules/@angular/forms';
import { UpdateprofileService } from '../service/userprofile/updateprofile.service';
import { NavBarsModule } from '../nav-bars/nav-bars/nav-bars.module';
import { NgxUiLoaderModule } from '../../../node_modules/ngx-ui-loader';



@NgModule({
  declarations: [
    MyprofileComponent,
    UpdateprofileComponent,

  ],
  imports: [
    CommonModule,
    FormsModule,
    NavBarsModule,
    NgxUiLoaderModule
  ],providers:[UserprofileService, UpdateprofileService],
  exports:[
    MyprofileComponent,
    UpdateprofileComponent
  ]
})
export class UserprofileModule { }
