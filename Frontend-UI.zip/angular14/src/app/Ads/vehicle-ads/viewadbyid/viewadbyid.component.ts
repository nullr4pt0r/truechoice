import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '../../../../../node_modules/@angular/router';
import { AdcrudService } from '../../../service/adservices/adcrud.service';
import { Adcrud } from '../../../model/Adcrudmodel/adcrud';

@Component({
  selector: 'app-viewadbyid',
  templateUrl: './viewadbyid.component.html',
  styleUrls: ['./viewadbyid.component.scss']
})
export class ViewadbyidComponent implements OnInit {
  ad!:Adcrud;
  id!:number;
  constructor(private route:ActivatedRoute, private adCrudService:AdcrudService) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    console.log(this.id);
    this.adCrudService.getAdById(this.id).subscribe(response => {
      this.ad = response;
    });
  }



}
