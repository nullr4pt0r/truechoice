package com.truebill.dev.controller;

import com.truebill.dev.DTO.Login;
import com.truebill.dev.entity.Users;
import com.truebill.dev.request.UserUpdateData;
import com.truebill.dev.service.UsersService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;


@RestController
@CrossOrigin(origins = "*")
//@RequestMapping("/api/v1")
public class UserController {
    Logger logger = LoggerFactory.getLogger(UserController.class);
    @Autowired
    private UsersService userservice;

    @GetMapping("/users")
    public ResponseEntity getAllUsers(@PageableDefault(value = 100) Pageable pageable){
        return userservice.getAllUser(pageable);
    }
    @PostMapping("/signup")
    public ResponseEntity signup(@Valid @RequestBody Users user){
        return userservice.createUser(user);
    }
    @PostMapping("/login")
    public ResponseEntity login(@Valid @RequestBody Login login){
        return userservice.VerifyUser(login);
    }

    @GetMapping("/uid/{uid}")
    public ResponseEntity findById(@PathVariable long uid){
        return userservice.findUser(uid);
    }

    @PutMapping("/edit/user/{uid}")
    public  ResponseEntity updateUserData(@PathVariable long uid, @RequestBody UserUpdateData data){
        return  userservice.updateUser(uid,data);
    }




}
