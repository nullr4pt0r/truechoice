import { Component, OnInit } from '@angular/core';
import { LoginModel } from '../../model/login';
import { FormGroup, FormControl, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthenticateModule } from '../authenticate.module';
import { LoginService } from '../../service/authentication/login.service';
import { SessionService } from '../../service/authentication/session.service';
import { Router } from '../../../../node_modules/@angular/router';
import Swal from 'sweetalert2';
import { UserdataService } from '../../service/userdata/userdata.service';
import { TitleCasePipe } from '../../../../node_modules/@angular/common';
@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent implements OnInit {
  login: LoginModel = new LoginModel();
  form: FormGroup;
  data: any;
  error:any = null;
  isLoading:boolean = false;
  username:any;

  constructor(private loginService: LoginService, private userDataService:UserdataService,private sessionService: SessionService, private router: Router) {
    this.form = new FormGroup({
      email: new FormControl(
        '', [Validators.email, Validators.required]
      ),
      password: new FormControl('',
        [Validators.required, Validators.minLength(8), Validators.maxLength(12)]
      )
    }
    );
  }

  ngOnInit(): void {

  }

  onSubmit() {
    const formValues = this.form.getRawValue();
    this.login.setEmail(formValues.email);
    this.login.setPassword(formValues.password);
    console.log(this.login);
    this.authenticate(this.login);
  }

  authenticate(login: LoginModel) {
    if (this.sessionService.checkSession()) {
      this.router.navigate(['/home']);
    }
    else {
      this.checkCredentials(this.login);
    }
  }



  checkCredentials(login: LoginModel) {
      this.loginService.login(login).subscribe(response => {
      console.log(response);
      this.data = response;
      this.sessionService.setSession(this.data);
      console.log(this.data);
      this.username = sessionStorage.getItem("username");
      let name = this.username;
        console.log("this.username for swal in login comp");
        console.log(this.username);
      this.sessionService.isAuthenticated = true;
      this.sessionService.isNotAuthenticated = false;
      // console.log(typeof username);
      setTimeout(()=>
      Swal.fire(
        'Welcome Back '+''+name[0].toUpperCase()+name.slice(1),"",
        "success"
      ),900
    );

      this.router.navigate(['home']);
      // return true;
    },
      errorMessage => {
        console.error(errorMessage);
        this.error = errorMessage;
        this.isLoading = false;
      });
  }



}
