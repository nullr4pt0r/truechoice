export class LoginModel {
  private   email !: string;
  private  password !: string;

  constructor(){

  }


//   constructor(email?:string,password?:string){
//       this.email=email;
//       this.password=password;
//   }

  setEmail(email:string){
      this.email =  email;
  }
  setPassword(password:string){
    this.password =  password;
}
  getEmail():string{
      return this.email;
  }
  getPassword():string{
      return this.password;
  }
}
