package com.truebill.dev.service;

import com.truebill.dev.entity.SellVehicleAd;
import com.truebill.dev.request.SellVehicleAdRequest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;



public interface SellVehicleService {
    ResponseEntity createAd(SellVehicleAdRequest vehicle);
    ResponseEntity findAdById(long vid);
    ResponseEntity findByVIN(String vin);
    ResponseEntity findAllAuto(long uid, Pageable pageable);
    //ResponseEntity findAllBySellerId(long uid);
    ResponseEntity updateSellVehicleAdBySellerIdAndVehicleId(long vid, SellVehicleAdRequest ad);

    ResponseEntity findAllAdByUser(long uid);
}
