package com.truebill.dev.enums;

public class DealStatus {

}
