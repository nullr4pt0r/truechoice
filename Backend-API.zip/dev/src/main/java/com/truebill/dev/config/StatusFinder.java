//package com.truebill.dev.config;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//@Configuration
//public class StatusFinder {
//
//    @Bean
//    public String statusToString(short status){
//        if(status == 1){
//            return "PUBLISHED";
//        }
//        else if(status == 2){
//            return "UNPUBLISHED";
//        }
//        else if(status == 3){
//            return "SOLD";
//        }
//        else if(status == 4){
//            return "DELETED";
//        }
//        else {
//            return "Invalid Status Code";
//        }
//    }

//     @Bean
//    public short stringToStatus(String status){
//        if(status == "PUBLISHED"){
//            return 1;
//        }
//        else if(status == "UNPUBLISHED"){
//            return 2;
//        }
//        else if(status == "SOLD"){
//            return 3;
//        }
//        else{
//            return 0;
//        }
//     }
//}
