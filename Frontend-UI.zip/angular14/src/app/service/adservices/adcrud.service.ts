import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import {Ad} from "../../model/ad";
import {Adcrud} from "../../model/Adcrudmodel/adcrud";
import {Observable,throwError} from 'rxjs';
import {catchError} from 'rxjs/operators';
import { UpdateAd } from '../../model/Adcrudmodel/update-ad';

@Injectable({
  providedIn: 'root'
})
export class AdcrudService {

  private baseURL = "http://localhost:9876/api/v1/seller";

  constructor(private httpclient:HttpClient,private router:Router) { }

  // createNewAd(ad:Ad):Observable<Object>{
  //   return this.httpclient.post(`${this.baseURL}/newauto`,ad)
  //   .pipe(
  //     catchError((errorRes)=>{
  //       console.error("Error response from service : "+errorRes);
  //       let errorMessage = "An Error Occured . Try again later";
  //       if (errorRes.error && errorRes.error.error instanceof Array){
  //       // if(!errorRes.error || !errorRes.error.message) {
  //        errorMessage = errorRes.error.error[0];
  //       // return throwError(errorMessage);
  //       }
  //        else {
  //         errorMessage = errorRes.error;
  //       }
  //       return throwError(errorMessage);
  //     })

  //   );

  // }

  createNewAd(ad: Ad): Observable<Object> {
    return this.httpclient.post(`${this.baseURL}/newauto`, ad)
    .pipe(
      catchError((errorRes) => {
        console.error( errorRes);
        let errorMessage = 'An error occurred. Please try again later.';
        console.log("error from service"+errorRes.status);

        if(errorRes.status >= 500){
          errorMessage = "An error occured on server side . We are working on the issue. Try again later !"
        }
        else if(errorRes.status > 400){
          console.log("from 400");
          errorMessage = errorRes.error;

        }
        else if(errorRes.error){
          console.log("from last else if");
          errorMessage = errorRes.error;
        }
        // if (errorRes.error && errorRes.error.error instanceof Array){
        //   errorMessage = errorRes.error.error[0];
        // }
        // else if(errorRes.status >= 500){
        //   errorMessage = "An error occured on server side . We are working on the issue. Try again later !"
        // }
        // else if(errorRes.status == 201){
        //   errorMessage= "New Ad created ";
        // }
        // else if(errorRes.status >= 300 && errorRes.status <=400){
        //   errorMessage = "Ad is already posted "
        // }

        return throwError(errorMessage);
      })
    );
  }

  getAdsByUserId(id:number,query:string):Observable<Adcrud[]>
  {
    return this.httpclient.get<Adcrud[]>(`${this.baseURL}/myauto/${id}/${query}`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }

  getAdById(id:number):Observable<Adcrud>{
    return this.httpclient.get<Adcrud>(`${this.baseURL}/auto/${id}`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }

  modifyAdById(id:number,ad:UpdateAd):Observable<Object>{
    return this.httpclient.put(`${this.baseURL}/edit/auto/${id}`,ad)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }

}
