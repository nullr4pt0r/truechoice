package com.truebill.dev.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DealResponse {
    private long dealId;
    private long vehicleId;
    private String seller;
    private String Buyer;
    private String buyerLocation;
    private String sellerLocation;
    private String buyerPhone;
    private String sellerPhone;
    private double finalQuote;
    private double buyerQuote;
    private double sellerQuote;
    private String vehicleKms;
    private  String status;
    private String vehicleRegno;
    private String createdAt;
    private String maker;
    private String model;
    private String variant;
}
