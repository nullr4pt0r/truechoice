import { Component, OnInit } from '@angular/core';
import { UserdataService } from '../../../service/userdata/userdata.service';
import {FormsModule,NgForm} from '@angular/forms';
import {Ad} from '../../../model/ad';
import {Makers} from '../../../model/makers';
import { MakerserviceService } from '../../../service/vehicleservices/makerservice.service';
import { Model } from '../../../model/model';
import { Set } from 'typescript';
import { AdcrudService } from '../../../service/adservices/adcrud.service';
import { Router } from '../../../../../node_modules/@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-postnewad',
  templateUrl: './postnewad.component.html',
  styleUrls: ['./postnewad.component.scss']
})
export class PostnewadComponent implements OnInit {

  newAd : Ad = new Ad();
  data : any;
  sellerId !: number;
  makerData !: Makers [];
  modelData !: Model[];
  makerId !: number;
  modelId !: number;
  filteredModel !: string[];
  filteredYear !: string[];
  filteredVariant !: string[];
  model !: string;
  year !: string;
  variant !: string;
  adResponse : any;


  constructor(private userdataservice:UserdataService,private router:Router,private vehicleService:MakerserviceService,private adcrudService:AdcrudService) { }

  ngOnInit(): void {
    this.data = this.userdataservice.getData();
    this.sellerId = this.data.userid;
    this.newAd.sellerId = this.sellerId;
    this.vehicleService.getMakers().subscribe(response=>{
      this.makerData = response as Makers[];
      console.log(this.makerData);
    });

  }

  onSubmit(){
    console.log(this.newAd);
    this.createAd(this.newAd);
  }

  createAd(newAd:Ad){
      this.adcrudService.createNewAd(newAd).subscribe(response => {
        this.adResponse = response;
        console.log("response "+response);
        // alert("message "+this.adResponse.message);
        console.log(this.adResponse);
        Swal.fire("Message",this.adResponse.message,"success");
        this.router.navigate(['/home']);


      },errorMessage => {
        console.error(errorMessage);
        Swal.fire("Error",errorMessage.error,"warning");

    });
  }


  getModel(){
    this.vehicleService.getModelByMakers(this.makerId).subscribe(response =>{
      this.modelData =  response as Model[];
      console.log(this.modelData);
      this.filteredModel = [];
      this.filteredVariant = [];
      this.filteredYear = [];
      this.getUniqueModel();

    });
    console.log(this.makerId);
    console.log();
  }

  getUniqueYear() {
    this.filteredVariant = [];
      this.filteredYear = [];
    console.log(this.model);
    // this.model = "Kwid";
   let  selectedModel = this.model;
   console.log(selectedModel);
    let years:any = [];
    for (let i = 0; i < this.modelData.length; i++) {
      if (this.modelData[i].model === selectedModel && !years.includes(this.modelData[i].year)) {
        years.push(this.modelData[i].year);
      }
    }
    console.log(years);
    this.filteredYear = years;
    console.log(this.filteredYear);
  }

  getVariants(){
    console.log(this.year);
    console.log(this.model);
    let variants:any = [];
    for(let i=0;i<this.modelData.length;i++){
      if(this.modelData[i].model === this.model &&  this.modelData[i].year === this.year && !variants.includes(this.modelData[i].variant)){
        variants.push(this.modelData[i].variant);
      }
    }
    console.log(variants);
    this.filteredVariant = variants;
    console.log(this.filteredVariant);
  }

  getUniqueModel(){
    // for(let i=0;i<this.modelData.length;i++){
    //   if(!this.filteredModel.includes(this.modelData[i].model)){
    //     this.filteredModel.push(this.modelData[i].model);
    //   }
    // }
    this.filteredModel = Array.from(new Set(this.modelData.map(model => model.model)));

    console.log(this.filteredModel);
  }

  getModelId(){

    for(let i=0;i<this.modelData.length;i++){
      if(this.modelData[i].model === this.model &&  this.modelData[i].year === this.year && this.modelData[i].variant === this.variant){
        this.modelId = this.modelData[i].modelId;
        break;
      }
    }
    this.newAd.modelId = this.modelId;
    console.log("model id is"+this.newAd.modelId);

  }


}
