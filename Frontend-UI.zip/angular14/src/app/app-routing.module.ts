import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
// import { LoginComponent } from './authentication/login/login.component';
import { HomeComponent } from './service/home/home.component';
import { StatisticsComponent } from './service/statistics/statistics.component';
import { AuthGuardGuard } from './guards/auth-guard.guard';
import { UserviewComponent } from './landing/userview/userview.component';
import { SigninComponent } from './authenticate/signin/signin.component';
import { SignupComponent } from './authenticate/signup/signup.component';
import { UserhomeComponent } from './useractions/userhome/userhome.component';
import { PostnewadComponent } from './Ads/vehicle-ads/postnewad/postnewad.component';
import { EditAdsComponent } from './Ads/vehicle-ads/edit-ads/edit-ads.component';
import { MyprofileComponent } from './userprofile/myprofile/myprofile.component';
import { UpdateprofileComponent } from './userprofile/updateprofile/updateprofile.component';
import { ViewAdsComponent } from './Ads/vehicle-ads/view-ads/view-ads.component';
import { ViewadbyidComponent } from './Ads/vehicle-ads/viewadbyid/viewadbyid.component';
import { SearchvehicleComponent } from './searchvehicle/searchvehicle/searchvehicle.component';
import { VehicledetailsComponent } from './searchvehicle/vehicledetails/vehicledetails/vehicledetails.component';
import { SalesdataComponent } from './deals/salesdata/salesdata.component';
import { BuydataComponent } from './deals/buydata/buydata.component';
import { ViewordersComponent } from './deals/vieworders/vieworders.component';
import { ViewsalesComponent } from './deals/viewsales/viewsales.component';
import { SelloffersviewComponent } from './deals/selloffersview/selloffersview.component';
import { BuyoffersviewComponent } from './deals/buyoffersview/buyoffersview.component';
import { ViewdealbyidComponent } from './deals/viewdealbyid/viewdealbyid.component';
import { IsSignedInGuardGuard } from './guards/is-signed-in-guard.guard';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { HistoryComponent } from './history/history/history.component';



const routes: Routes = [
  {path:'home',component: UserhomeComponent, canActivate : [AuthGuardGuard]},
  {path:'statistics',component: StatisticsComponent, canActivate : [AuthGuardGuard]},
  {path:'login',component:SigninComponent,canActivate:[IsSignedInGuardGuard]},
  {path:'signup',component:SignupComponent,canActivate:[IsSignedInGuardGuard]},
  // {path:'signin',component:LoginComponent},
  {path:'sellvehicle',component:PostnewadComponent, canActivate:[AuthGuardGuard]},
  {path:'viewads',component:ViewAdsComponent, canActivate:[AuthGuardGuard]},
  {path:'editad/:id',component:EditAdsComponent,canActivate:[AuthGuardGuard]},
  {path:'viewad/:id',component:ViewadbyidComponent,canActivate:[AuthGuardGuard]},
  {path:'editprofile',component:UpdateprofileComponent,canActivate:[AuthGuardGuard]},
  {path:'myprofile',component:MyprofileComponent,canActivate:[AuthGuardGuard]},
  {path:'search',component:SearchvehicleComponent},
  {path:'buy',component:SearchvehicleComponent},
  {path:'vehicle/:id',component:VehicledetailsComponent,canActivate:[AuthGuardGuard]},
  {path:'',component: SearchvehicleComponent},
  {path:'orders',component:ViewordersComponent,canActivate:[AuthGuardGuard]},
  {path:'sales',component:ViewsalesComponent,canActivate:[AuthGuardGuard]},
  {path:'view/offers/sell',component:SelloffersviewComponent,canActivate:[AuthGuardGuard]},
  {path:'view/offers/buy',component:BuyoffersviewComponent,canActivate:[AuthGuardGuard]},
  {path:'sell/bill/:id',component:SalesdataComponent,canActivate:[AuthGuardGuard]},
  {path:'view/offer/:id',component:ViewdealbyidComponent,canActivate:[AuthGuardGuard]},
  {path:'buy/bill/:id',component:BuydataComponent,canActivate:[AuthGuardGuard]},
  {path:'history',component:HistoryComponent,canActivate:[AuthGuardGuard]},
  {path:"#",component:SearchvehicleComponent},
  {path:'**',pathMatch:'full',component:PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
