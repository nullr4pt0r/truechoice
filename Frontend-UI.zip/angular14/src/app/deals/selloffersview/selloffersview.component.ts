import { Component, OnInit } from '@angular/core';
import { Router } from '../../../../node_modules/@angular/router';
import { UserdataService } from '../../service/userdata/userdata.service';
import { FetchdealdataService } from '../../service/dealService/fetchdealdata.service';
import { DealRecord } from '../../model/dealRecords/dealrecord';
import { DealRequest } from '../../model/dealRecords/deal-request';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-selloffersview',
  templateUrl: './selloffersview.component.html',
  styleUrls: ['./selloffersview.component.scss']
})
export class SelloffersviewComponent implements OnInit {
  salesData !: DealRecord[];
  showContent !: boolean;
  id !: number;
  dtOptions : DataTables.Settings = {};

  constructor(private router:Router , private userdataService: UserdataService, private dealDataService:FetchdealdataService) { }

  request!:DealRequest;
  ngOnInit(): void {
    this.request = {};
    this.id = this.userdataService.getData().userid;
    console.log(this.id);
    this.dealDataService.getAllDealPendingBySellerId(this.id).subscribe(response =>{
      this.salesData = response as DealRecord[];
      console.log(response);
      console.log(this.salesData);
    });
    this.dtOptions = {
      pagingType: 'full_numbers',
      lengthMenu: [5,10,15,20],
      pageLength : 5,
      processing: true
    },
    setTimeout(()=>this.showContent=true, 250)
  }

  viewDeal(id:number){
    this.router.navigate(["/view/offer/",id]);
  }

  accept(id:number,vid:number){
    this.request.dealId = id;
    this.request.status = 1;
    this.request.vehicleId = vid;
    this.sellerResponse(this.request);
  }
  reject(id:number,vid:number){
    this.request.dealId = id;
    this.request.status = 3;
    this.request.vehicleId = vid;
    this.sellerResponse(this.request);
  }

  sellerResponse(response:DealRequest){
    this.dealDataService.sellerDealAction(response).subscribe(response =>{
      console.log(response);
      Swal.fire("Response send successfully","","success");
      location.reload();
    },error =>{
      console.log(error);
      Swal.fire("Error",error.message,"error");
    })
  }


}
