import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
// import { LoginModel } from '../../model/login';
import { Router } from '@angular/router';
import {SessionService} from '../authentication/session.service';
import {Observable,throwError} from 'rxjs';
import {catchError} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FetchaddataService {

  constructor(private httpClient:HttpClient, private sessionService:SessionService, private router:Router) { }



  private baseURL = "http://localhost:9876/api/v1/seller";

  getAdbyUserId(id:number):Observable<object>{
    console.log(id);
    return this.httpClient.get<object>(`${this.baseURL}/myauto/${id}/count`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }
}
