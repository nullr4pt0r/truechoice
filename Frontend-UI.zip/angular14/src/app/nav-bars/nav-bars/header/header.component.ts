import { Component, OnInit, Output, EventEmitter, SimpleChanges, ChangeDetectorRef } from '@angular/core';
import { LoginService } from '../../../service/authentication/login.service';
import { Router } from '../../../../../node_modules/@angular/router';
import { SessionService } from '../../../service/authentication/session.service';
import { UserdataService } from '../../../service/userdata/userdata.service';
import { Location } from '@angular/common';
import { OnChanges, Input } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
   count = 0;
   nestedcount = 0;
isAllowedToCheck:boolean = true;
  name !: any;
  constructor(public authService: LoginService,private cd: ChangeDetectorRef,private location: Location,private userdataService:UserdataService,private router: Router, public sessionService: SessionService) {

  }
  ngOnInit(): void {
    this.sessionService.checkSession();

    console.log("Printing after logged in");
    console.log("Within ngOnInit");
    if(this.sessionService.isAuthenticated){
      this.name = sessionStorage.getItem("username");
      console.log(this.sessionService.isAuthenticated);
      console.log(this.name);

  }

    console.log(this.name);
  }

//   ngOnChanges(changes : SimpleChanges):void
// {
//   console.log("Printing after logged in");
//     console.log("Within ngOnCHanges");

//       if (this.sessionService.isAuthenticated) {
//         this.name = sessionStorage.getItem('username');

//       }


// }

ngDoCheck() {
  console.log("From ngDoCheck");
  console.log("coutn is : "+this.count);
  this.count ++;
  if(this.isAllowedToCheck){
  if (this.sessionService.isAuthenticated) {
    this.name = sessionStorage.getItem("username");
    this.isAllowedToCheck = false;
    console.log("nexted count : "+this.nestedcount)
  }
}
}

// ngAfterViewChecked() {
//   console.log("From AfterViewChecked");
//   console.log("coutn is : "+this.count);
//   this.count ++;
//   if(this.isAllowedToCheck){
//   if (this.sessionService.isAuthenticated) {
//     this.name = sessionStorage.getItem("username");
//     this.isAllowedToCheck = false;
//     console.log("nexted count : "+this.nestedcount)
//   }
// }
// }



  gotoProfile(){
    this.router.navigate(['/myprofile']);
  }

  // sideNav(){
  //   this.menustatus = !this.menustatus;
  //   this.sideNavToggled.emit(this.menustatus);
  //

  // SideNavToggle() {
  //   this.menuStatus = !this.menuStatus;
  //   this.sideNavToggled.emit(this.menuStatus);
  //   console.log(this.sideNavToggled.emit(this.menuStatus));
  //   console.log(this.menuStatus);
  // }

  login() {
    this.router.navigate(['/login']);
  }
  logout() {
    this.authService.logout();
  }
  signup(){
    this.router.navigate(['/signup']);
  }
  search(name:string){
    console.log(name);
  }
  goToHome(){
    this.router.navigate(['home']);
  }
  goBack() {
    this.location.back();
  }

}
