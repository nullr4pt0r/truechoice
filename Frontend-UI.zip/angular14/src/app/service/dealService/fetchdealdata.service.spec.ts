import { TestBed } from '@angular/core/testing';

import { FetchdealdataService } from './fetchdealdata.service';

describe('FetchdealdataService', () => {
  let service: FetchdealdataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FetchdealdataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
