import { Component, OnInit } from '@angular/core';
import { Router } from '../../../../node_modules/@angular/router';
import { UserdataService } from '../../service/userdata/userdata.service';
import { DealRecord } from '../../model/dealRecords/dealrecord';
import { FetchdealdataService } from '../../service/dealService/fetchdealdata.service';

@Component({
  selector: 'app-viewsales',
  templateUrl: './viewsales.component.html',
  styleUrls: ['./viewsales.component.scss']
})
export class ViewsalesComponent implements OnInit {
  salesData !: DealRecord[];
  showContent !: boolean;
  id !: number;
  dtOptions : DataTables.Settings = {};

  constructor(private router:Router , private userdataService: UserdataService, private dealDataService:FetchdealdataService) { }


  ngOnInit(): void {
    this.id = this.userdataService.getData().userid;
    console.log(this.id);
    this.dealDataService.getAllDealDataBySellerId(this.id).subscribe(response =>{
      this.salesData = response as DealRecord[];
      console.log(response);
      console.log(this.salesData);
    });
    this.dtOptions = {
      pagingType: 'full_numbers',
      lengthMenu: [5,10,15,20],
      pageLength : 5,
      processing: true
    },
    setTimeout(()=>this.showContent=true, 250)
  }

  viewDeal(id:number){
    this.router.navigate(["/sell/bill/",id]);
  }
}

