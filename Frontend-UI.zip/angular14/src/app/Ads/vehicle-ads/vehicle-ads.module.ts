import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PostnewadComponent } from './postnewad/postnewad.component';
import { SessionService } from '../../service/authentication/session.service';
import { UserdataService } from '../../service/userdata/userdata.service';
import { FetchaddataService } from '../../service/adservices/fetchaddata.service';
import { FormsModule } from '../../../../node_modules/@angular/forms';
import { MakerserviceService } from '../../service/vehicleservices/makerservice.service';
import { AdcrudService } from '../../service/adservices/adcrud.service';

import { ViewAdsComponent } from './view-ads/view-ads.component';
import { EditAdsComponent } from './edit-ads/edit-ads.component';
import { LocationsService } from '../../service/location/locations.service';
import {DataTablesModule} from 'angular-datatables';
import { ViewadbyidComponent } from './viewadbyid/viewadbyid.component';
import { NavBarsModule } from '../../nav-bars/nav-bars/nav-bars.module';
import { NgxUiLoaderModule } from "ngx-ui-loader";


@NgModule({
  declarations: [
    PostnewadComponent,
    ViewAdsComponent,
    EditAdsComponent,
    ViewadbyidComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    DataTablesModule,
    NavBarsModule,
    NgxUiLoaderModule
  ],
  providers:[SessionService,LocationsService,UserdataService,FetchaddataService,MakerserviceService,AdcrudService],
  exports:[
    PostnewadComponent,
    ViewAdsComponent,
    EditAdsComponent,
    ViewadbyidComponent
  ]
})
export class VehicleAdsModule { }
