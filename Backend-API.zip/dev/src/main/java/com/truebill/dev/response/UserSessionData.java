package com.truebill.dev.response;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UserSessionData {
    private long uid;
    private String username;
    private String fullName;
    private String location;
    private String userType;
    private String phoneNumber;


    public UserSessionData() {
    }

    public UserSessionData(long uid, String username, String fullName, String location, String userType, String phoneNumber) {
        this.uid = uid;
        this.username = username;
        this.fullName = fullName;
        this.location = location;
        this.userType = userType;
        this.phoneNumber = phoneNumber;
    }
}
