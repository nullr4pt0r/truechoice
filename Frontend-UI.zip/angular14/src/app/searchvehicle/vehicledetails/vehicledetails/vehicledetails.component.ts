import { Component, OnInit } from '@angular/core';
import { AdcrudService } from '../../../service/adservices/adcrud.service';
import { ActivatedRoute } from '../../../../../node_modules/@angular/router';
import { SearchvehicledetailsService } from '../../../service/searchvehicle/searchvehicledetails.service';
import { Location } from '@angular/common';
import { DealRecord } from '../../../model/dealRecords/dealrecord';
import { DealRequest } from '../../../model/dealRecords/deal-request';
import { UserdataService } from '../../../service/userdata/userdata.service';
import { FetchdealdataService } from '../../../service/dealService/fetchdealdata.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-vehicledetails',
  templateUrl: './vehicledetails.component.html',
  styleUrls: ['./vehicledetails.component.scss']
})
export class VehicledetailsComponent implements OnInit {
  id!:number;
  uid !: number;
  offerPrice !: number;
  ad :any;
  showSlider :boolean = false;
  dealRequest!: DealRequest;
  constructor(private route:ActivatedRoute,private userDataService:UserdataService,private location: Location, private vehicleSearch:SearchvehicledetailsService,private dealService:FetchdealdataService){

  }

  ngOnInit(): void {
    this.uid = this.userDataService.getData().userid;
    this.id = this.route.snapshot.params['id'];
    console.log(this.id);
    this.dealRequest = {};
    this.vehicleSearch.searchVehicle(this.id).subscribe( response => {
      console.log(response);
      this.ad = response;
      console.log("this is ad data");
      console.log(this.ad);
    },errorMessage =>{
      console.error(errorMessage);
      // alert("Error: "+errorMessage);
      Swal.fire("Error",errorMessage,"error");
    }

  );
  }
  goBack() {
    this.location.back();
  }
  buy(){
    this.showSlider = true;
  }
  makeOffer(){
    this.dealRequest.vehicleId = this.ad.vehicleId;
    // this.dealRequest.vehicleRegno = this.ad.vehicleRegno;
    // this.dealRequest.sellerId = this.ad.sellerId;
    this.dealRequest.buyerId = this.uid;
    this.dealRequest.status = 2;
    this.dealRequest.dealId = 0;
    this.dealRequest.buyerQuote = this.offerPrice;
    console.log(this.dealRequest);
    this.postRequest(this.dealRequest);
  }

  postRequest(dealService:DealRequest){
    this.dealService.createNewDealRequest(this.dealRequest).subscribe(response =>{
      console.log(response);
      // alert("Offer Created Successfully !");
      Swal.fire("Success","Offer Created Successfully !","success");
      // setTimeout(() => {
      //   window.location.reload();
      // }, 40);
    },
    errorMessage =>
    Swal.fire("Error",errorMessage.message,"error")
  );
  }


}
