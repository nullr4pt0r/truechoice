import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../../model/user';
import {Observable,throwError} from 'rxjs';
import {catchError} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UpdateprofileService {
  private baseURL = 'http://localhost:9876/api/v1';

  constructor(private httpclient:HttpClient) { }

  // editprofile(user:User,uid:number):Observable<object>{
  //     return this.httpclient.put(`${this.baseURL}/edit/user/${uid}`,user);
  // }

  editProfile(user: User, uid: number): Observable<object> {
    return this.httpclient
      .put(`${this.baseURL}/edit/user/${uid}`, user)
      .pipe(
        catchError(errorRes => {
          console.error("Error response from service:", errorRes);
          let errorMessage = "An error occurred. Please try again later.";
          if (errorRes.error && errorRes.error.error instanceof Array) {
            errorMessage = errorRes.error.error[0];
          } else if (errorRes.error) {
            errorMessage = errorRes.error;
          }
          return throwError(errorMessage);
        })
      );
  }


}
