package com.truebill.dev.service;

import com.truebill.dev.controller.DealsController;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.truebill.dev.entity.SellVehicleAd;
import com.truebill.dev.entity.Users;
import com.truebill.dev.entity.VehicleDeals;
import com.truebill.dev.repository.SellVehicleRepository;
import com.truebill.dev.repository.UserRepository;
import com.truebill.dev.repository.VehicleDealsRepository;
import com.truebill.dev.request.DealRecord;
import com.truebill.dev.request.DealRequest;
import com.truebill.dev.response.DealResponse;
import com.truebill.dev.response.SellerAdResponse;
import com.truebill.dev.utils.JsonResponse;
import com.truebill.dev.utils.ValidationUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestHeader;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class VehicleDealsServiceImpl implements  VehicleDealsService{

    Logger logger = LoggerFactory.getLogger(VehicleDealsServiceImpl.class);

    @Autowired
    private VehicleDealsRepository vehicleDealsRepo;

    @Autowired
    private SellVehicleRepository sellVehicleRepo;

    @Autowired
    private UserRepository userRepo;

    static ModelMapper modelMapper = new ModelMapper();
    static String dealStatusToString(short dealStatus){
        if(dealStatus == 1){
            return "SOLD";
        }
        else if(dealStatus == 2){
            return "IN NEGOTIATION";
        }
        else if(dealStatus == 3){
            return "REJECTED";
        }
        else if(dealStatus == 4){
            return "ACCEPTED";
        }
        else {
            return "Invalid Status Code";
        }
    }

    static DealResponse mapEntitytoDTO(VehicleDeals deal){
//        DealResponse dealRes = modelMapper.map(deal, DealResponse.class);
        DealResponse dealRes = new DealResponse();
        dealRes.setDealId(deal.getDealId());
        dealRes.setVehicleId(deal.getVehicleId().getVehicleId());
        dealRes.setVehicleRegno(deal.getVehicleRegno());
        dealRes.setBuyerLocation(deal.getBuyer().getLocation());
        dealRes.setFinalQuote(deal.getFinalQuote());
        dealRes.setVehicleKms(deal.getVehicleId().getVehicleKms());
        dealRes.setSellerLocation(deal.getSeller().getLocation());
        dealRes.setSellerPhone(deal.getSeller().getPhoneNumber());
        dealRes.setBuyerPhone(deal.getBuyer().getPhoneNumber());
        dealRes.setSeller(deal.getSeller().getFullName());
        dealRes.setBuyer(deal.getBuyer().getFullName());
        dealRes.setStatus(dealStatusToString(deal.getDealStatus()));
        dealRes.setMaker(deal.getVehicleId().getModel().getMaker().getMaker());
        dealRes.setModel(deal.getVehicleId().getModel().getModel());
        dealRes.setVariant(deal.getVehicleId().getModel().getVariant());
        dealRes.setCreatedAt(new SimpleDateFormat("yyyy-MM-dd").format(deal.getCreatedAt()));
        return dealRes;
    }

    static DealResponse limitedMapEntitytoDTO(VehicleDeals deal){
        DealResponse dealRes = new DealResponse();
        dealRes.setVehicleId(deal.getVehicleId().getVehicleId());
        dealRes.setDealId(deal.getDealId());
        dealRes.setBuyerLocation("******");
        dealRes.setSellerLocation("******");
        dealRes.setVehicleRegno("XXXXXXXXX");
        dealRes.setSellerQuote(deal.getVehicleId().getVehiclePrice());
        dealRes.setBuyerQuote(deal.getBuyerQuote());
        dealRes.setVehicleKms(deal.getVehicleId().getVehicleKms());
        dealRes.setSellerPhone("XXXXXXXXXX");
        dealRes.setBuyerPhone("XXXXXXXXXX");
        dealRes.setSeller("**********");
        dealRes.setBuyer("**********");
        dealRes.setStatus(dealStatusToString(deal.getDealStatus()));
        dealRes.setMaker(deal.getVehicleId().getModel().getMaker().getMaker());
        dealRes.setModel(deal.getVehicleId().getModel().getModel());
        dealRes.setVariant(deal.getVehicleId().getModel().getVariant());
        dealRes.setCreatedAt(new SimpleDateFormat("yyyy-MM-dd").format(deal.getCreatedAt()));
        return dealRes;
    }

    static DealResponse sellerMapEntitytoDTO(VehicleDeals deal){
        DealResponse dealRes = new DealResponse();
        dealRes.setVehicleId(deal.getVehicleId().getVehicleId());
        dealRes.setDealId(deal.getDealId());
        dealRes.setBuyerLocation("******");
        dealRes.setSellerLocation("******");
        dealRes.setVehicleRegno(deal.getVehicleRegno());
        dealRes.setSellerQuote(deal.getVehicleId().getVehiclePrice());
        dealRes.setBuyerQuote(deal.getBuyerQuote());
        dealRes.setVehicleKms(deal.getVehicleId().getVehicleKms());
        dealRes.setSellerPhone("XXXXXXXXXX");
        dealRes.setBuyerPhone("XXXXXXXXXX");
        dealRes.setSeller("**********");
        dealRes.setBuyer("**********");
//        dealRes.setStatus(dealStatusToString(deal.getDealStatus()));
        if(deal.getDealStatus() == 1){
            dealRes.setStatus("SOLD");
        }
        else if(deal.getDealStatus() == 3){
            dealRes.setStatus("REJECTED DEAL");
        }
        else{
            dealRes.setStatus(dealStatusToString(deal.getDealStatus()));
        }
        dealRes.setMaker(deal.getVehicleId().getModel().getMaker().getMaker());
        dealRes.setModel(deal.getVehicleId().getModel().getModel());
        dealRes.setVariant(deal.getVehicleId().getModel().getVariant());
        dealRes.setCreatedAt(new SimpleDateFormat("yyyy-MM-dd").format(deal.getCreatedAt()));
        return dealRes;
    }
    static DealResponse buyerMapEntitytoDTO(VehicleDeals deal){
        DealResponse dealRes = new DealResponse();
        dealRes.setVehicleId(deal.getVehicleId().getVehicleId());
        dealRes.setDealId(deal.getDealId());
        dealRes.setBuyerLocation("******");
        dealRes.setSellerLocation("******");
        dealRes.setVehicleRegno(deal.getVehicleRegno());
        dealRes.setSellerQuote(deal.getVehicleId().getVehiclePrice());
        dealRes.setBuyerQuote(deal.getBuyerQuote());
        dealRes.setVehicleKms(deal.getVehicleId().getVehicleKms());
        dealRes.setSellerPhone("XXXXXXXXXX");
        dealRes.setBuyerPhone("XXXXXXXXXX");
        dealRes.setSeller("**********");
        dealRes.setBuyer("**********");
        if(deal.getDealStatus() == 1){
            dealRes.setStatus("PURCHASED");
        }
        else if(deal.getDealStatus() == 3){
            dealRes.setStatus("SELLER REJECTED DEAL");
        }
        else{
            dealRes.setStatus(dealStatusToString(deal.getDealStatus()));
        }
//        dealRes.setStatus(dealStatusToString(deal.getDealStatus()));
        dealRes.setMaker(deal.getVehicleId().getModel().getMaker().getMaker());
        dealRes.setModel(deal.getVehicleId().getModel().getModel());
        dealRes.setVariant(deal.getVehicleId().getModel().getVariant());
        dealRes.setCreatedAt(new SimpleDateFormat("yyyy-MM-dd").format(deal.getCreatedAt()));
        return dealRes;
    }

//    public  void invalidateDeals(long vehicleId,long userId, short dealStatus){
//        logger.info(String.valueOf(vehicleId));
//        logger.info(String.valueOf(userId));
//        logger.info(String.valueOf(dealStatus));
//        boolean value = vehicleDealsRepo.existsByVehicleIdVehicleIdAndSellerUserIdAndDealStatus(vehicleId,userId,dealStatus);
//        if(value){
//            List<VehicleDeals>deals = vehicleDealsRepo.findByVehicleIdVehicleIdAndSellerUserIdAndDealStatus(vehicleId,userId,dealStatus);
//
//            if(deals.isEmpty()){
//                logger.info("Nothing to do with other deals");
//            }
//            else if( deals.size() > 0){
//                for(VehicleDeals deal : deals){
//                    deal.setDealStatus((short) 3);
//                    logger.info("deals invalidating"+deal.getDealStatus());
//                    logger.info("going to save ...");
//                    vehicleDealsRepo.save(deal);
//                    logger.info("done");
//                }
//            }
//        }
//
//    }


    @Override
    public ResponseEntity buy(DealRecord deal) {
        Double cost = 0.00;

        if(deal.getFinalQuote()!=null && !deal.getFinalQuote().equals("")){
            cost = Double.parseDouble(deal.getFinalQuote());
        }
        else if(cost == 0.00 || deal.getFinalQuote() == null ||deal.getFinalQuote().equals("") ){
            return  ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new JsonResponse("Cost invalid"));
        }
        Optional<SellVehicleAd> ad = sellVehicleRepo.findByvehicleId(deal.getVehicleId());
        Optional<Users> buyer = userRepo.findByUserId(deal.getBuyerId());
        Optional<Users> seller = userRepo.findByUserId(deal.getSellerId());
//        int value = vehicleDealsRepo.countVehicleIdSoldBySeller((long)ad.get().getVehicleId(),(long)ad.get().getSeller().getUserId());
        boolean value = vehicleDealsRepo.existsByVehicleIdVehicleIdAndSellerUserIdAndDealStatus(ad.get().getVehicleId(),ad.get().getSeller().getUserId(),(short) 1);
        logger.info(String.valueOf(value));
//        boolean s = value > 0 ? true : false;
        if(ad.isEmpty() || buyer.isEmpty() || seller.isEmpty()){
            return ResponseEntity.status(404).body(new JsonResponse("ad or buyer or seller is empty from db"));
        }
        if(!ad.get().getVehicleRegno().equals(deal.getVehicleRegno())){
            logger.info("ad vehicle no "+ad.get().getVehicleRegno());
            logger.info("vehicle no from request "+deal.getVehicleRegno());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(new JsonResponse("vehicle no conflict"));
        } else if(ad.get().getSeller().getUserId() != deal.getSellerId()){
            return ResponseEntity.status(HttpStatus.CONFLICT).body(new JsonResponse("seller id conflict"));
        }
        else if(value){
           logger.info("issue is here    "+value);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new JsonResponse("Sold car cannot sold again"));
        }

        VehicleDeals deals = new VehicleDeals();
        deals.setVehicleId(ad.get());
        deals.setVehicleRegno(ad.get().getVehicleRegno());
        deals.setBuyer(buyer.get());
        deals.setSeller(seller.get());
        deals.setFinalQuote(cost);
        deals.setDealStatus((short) 1);
        vehicleDealsRepo.save(deals);

       SellVehicleAd modifyAd = sellVehicleRepo.findByvehicleId(ad.get().getVehicleId()).get();
       modifyAd.setStatus((short) 3);
       sellVehicleRepo.save(modifyAd);

        return ResponseEntity.status(200).body(new JsonResponse("Deal created successfully"));
    }

    @Override
    public ResponseEntity getCarSellCountByUserId(long uid) {
        ResponseEntity responseEntity = ValidationUtils.validateUserId(uid);
        return ResponseEntity.status(200).body(vehicleDealsRepo.countDealIdBySellerUserIdAndDealStatus(uid,(short) 1));
    }

    @Override
    public ResponseEntity getCarBuyCountByUserId(long uid) {
        ResponseEntity responseEntity = ValidationUtils.validateUserId(uid);
        return ResponseEntity.status(200).body(vehicleDealsRepo.countDealIdByBuyerUserIdAndDealStatus(uid,(short) 1));
    }

    @Override
    public ResponseEntity getCarSellOffersCountBySellerId(long uid) {
        return ResponseEntity.status(200).body(vehicleDealsRepo.countDealIdBySellerUserIdAndDealStatus(uid,(short)2));
    }

    @Override
    public ResponseEntity getCarBuyOfferCountByBuyerId(long uid) {
        return ResponseEntity.status(200).body(vehicleDealsRepo.countDealIdByBuyerUserIdAndDealStatus(uid,(short)2));

    }

    @Override
    public ResponseEntity getDealResponseByDealIdAndSellerId(long dealid,long uid) {
        ResponseEntity responseEntity = ValidationUtils.validateUserId(uid);
//        Optional<VehicleDeals> deal = vehicleDealsRepo.findById(dealid);
//        if(!deal.isPresent()){
//            return ResponseEntity.status(404).body("Deal is not present");
//        }
//       if(deal.get().getSeller().getUserId() == uid && deal.get().getBuyer().getUserId() != uid) {
//           VehicleDeals deals = deal.get();
//           DealResponse dealResponse = new DealResponse();
//           dealResponse = mapEntitytoDTO(deals,dealResponse);
//           return ResponseEntity.status(200).body(dealResponse);
//       }
//        return ResponseEntity.status(404).body("");
        Optional<VehicleDeals> deals = vehicleDealsRepo.findByDealId(dealid);
        if(!deals.isPresent()){
                return ResponseEntity.status(404).body(new JsonResponse("Deal is not present"));
            }
            if(deals.get().getSeller().getUserId() != uid || deals.get().getBuyer().getUserId() == uid) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body(new JsonResponse("Seller & Buyer Id conflict"));
            }
            DealResponse dealResponse = mapEntitytoDTO(deals.get());
            return ResponseEntity.status(200).body(dealResponse);
        }

    @Override
    public ResponseEntity getDealResponseByDealIdAndBuyerId(long dealid,long uid) {
        ResponseEntity responseEntity = ValidationUtils.validateUserId(uid);
        Optional<VehicleDeals> deal = vehicleDealsRepo.findByDealId(dealid);
        if(!deal.isPresent()){
            return ResponseEntity.status(404).body(new JsonResponse("Deal is not present"));
        }
        if(deal.get().getSeller().getUserId() != uid && deal.get().getBuyer().getUserId() == uid) {
            VehicleDeals deals = deal.get();
            DealResponse dealResponse = new DealResponse();
            dealResponse = mapEntitytoDTO(deals);
            return ResponseEntity.status(200).body(dealResponse);
        }
        return ResponseEntity.status(404).body("");
    }

    @Override
    public ResponseEntity getDealResponse(long dealid,long uid) {
        ResponseEntity responseEntity = ValidationUtils.validateUserId(uid);
        Optional<VehicleDeals> deal = vehicleDealsRepo.findByDealId(dealid);
        if(!deal.isPresent()){
            return ResponseEntity.status(404).body(new JsonResponse("Deal is not present"));
        }
        if(deal.get().getSeller().getUserId() == uid && deal.get().getBuyer().getUserId() != uid) {
            VehicleDeals deals = deal.get();
            DealResponse dealResponse = new DealResponse();
            dealResponse = mapEntitytoDTO(deals);
            return ResponseEntity.status(200).body(dealResponse);
        } else if(deal.get().getBuyer().getUserId() == uid && deal.get().getSeller().getUserId() != uid) {
            VehicleDeals deals = deal.get();
            DealResponse dealResponse = new DealResponse();
            dealResponse = mapEntitytoDTO(deals);
            return ResponseEntity.status(200).body(dealResponse);
        }
        return ResponseEntity.status(404).body("");
    }

    @Override
    public ResponseEntity getAllDealDataBySellerId(long uid,@PageableDefault(value = 100) Pageable pageable) {
        ResponseEntity responseEntity = ValidationUtils.validateUserId(uid);
        Page<VehicleDeals> deals = vehicleDealsRepo.findAllBySellerUserIdAndDealStatus(uid,(short) 1,pageable);
        List<DealResponse> response = new ArrayList<>();
        for(VehicleDeals deal:deals){
            DealResponse responseDeal = new DealResponse();
            responseDeal = mapEntitytoDTO(deal);
            response.add(responseDeal);
        }
        return ResponseEntity.status(200).body(response);
    }

    @Override
    public ResponseEntity getAllDealDataByBuyerId(long uid,@PageableDefault(value = 100) Pageable pageable) {
        ResponseEntity responseEntity = ValidationUtils.validateUserId(uid);
        Page<VehicleDeals> deals = vehicleDealsRepo.findAllByBuyerUserIdAndDealStatus(uid,(short) 1,pageable);
        List<DealResponse> response = new ArrayList<>();
        for(VehicleDeals deal:deals){
            DealResponse responseDeal = new DealResponse();
            responseDeal = mapEntitytoDTO(deal);
            response.add(responseDeal);
        }
        return ResponseEntity.status(200).body(response);
    }

    @Override
    public ResponseEntity newDealRequest(DealRequest dealRequest) {
        Optional<SellVehicleAd> ad = sellVehicleRepo.findByvehicleId(dealRequest.getVehicleId());
        Optional<Users> buyer = userRepo.findByUserId(dealRequest.getBuyerId());
        boolean value = vehicleDealsRepo.existsByVehicleIdVehicleIdAndSellerUserIdAndDealStatus(ad.get().getVehicleId(),ad.get().getSeller().getUserId(),(short) 1);
        boolean value2 = vehicleDealsRepo.existsByVehicleIdVehicleIdAndSellerUserIdAndBuyerUserIdAndDealStatus(ad.get().getVehicleId(),ad.get().getSeller().getUserId(),buyer.get().getUserId(),(short) 2);

        if(!ad.isPresent() || !buyer.isPresent()){
            return ResponseEntity.status(404).body(new JsonResponse("Ad or BuyerId is invalid"));
        }
        else if(value){
            logger.info("issue is here  in deal request  "+value);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new JsonResponse("Sold car cannot requested again"));
        }else if(value2){
            logger.info("already created request");
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).body(new JsonResponse("Your request for this ad is already under seller consideration"));
        }

        logger.info("Passed checks");

        VehicleDeals deal = new VehicleDeals();
        deal.setDealStatus((short)2);
        deal.setVehicleId(ad.get());
        deal.setBuyer(buyer.get());
        deal.setVehicleRegno(ad.get().getVehicleRegno());
        deal.setBuyerQuote(dealRequest.getBuyerQuote());
        deal.setFinalQuote(0.00);
        deal.setSeller(ad.get().getSeller());
        vehicleDealsRepo.save(deal);
        return ResponseEntity.status(201).body(new JsonResponse("Request Created Successfully"));
    }

    @Override
    public ResponseEntity dealAction(DealRequest dealRequest) {
        logger.info("seller action");
        Optional<SellVehicleAd> ad = sellVehicleRepo.findByvehicleId(dealRequest.getVehicleId());

        if(!ad.isPresent()){
            logger.info("ad not present");
            return ResponseEntity.status(404).body(new JsonResponse("Ad is invalid"));
        }

        Optional<VehicleDeals> deals = vehicleDealsRepo.findByDealId(dealRequest.getDealId());
        Optional<Users> buyer = userRepo.findByUserId(deals.get().getBuyer().getUserId());
        if(!deals.isPresent()){
            logger.info("deal not prosent");
            return ResponseEntity.status(404).body(new JsonResponse("Deal not found"));
        }
        else if(buyer.isEmpty()){
            logger.info("buyer not found");
            return ResponseEntity.status(404).body(new JsonResponse("Buyer not found"));
        }

        VehicleDeals deal = deals.get();
        if(dealRequest.getStatus() == 1 && deals.get().getDealStatus() == 2 ){
            boolean value = vehicleDealsRepo.existsByVehicleIdVehicleIdAndSellerUserIdAndDealStatus(ad.get().getVehicleId(),ad.get().getSeller().getUserId(),(short) 1);
            if(value){
                logger.info("Car already sold by the seller !");
                return ResponseEntity.status(403).body(new JsonResponse("Your car Already Sold !"));
            }
            logger.info("sold");
            deal.setDealStatus((short) 1);
            deal.setFinalQuote(deal.getBuyerQuote());
            logger.info("changing the status in sellvehicle ad");
            SellVehicleAd modifyAd = sellVehicleRepo.findByvehicleId(deal.getVehicleId().getVehicleId()).get();
            modifyAd.setStatus((short) 3);
            logger.info("data changed successfully");
            sellVehicleRepo.save(modifyAd);
            vehicleDealsRepo.save(deal);
            vehicleDealsRepo.invalidateDealsByVehicleIdAndSellerIdAndDealStatus(deal.getVehicleId().getVehicleId(),deal.getSeller().getUserId(),(short)2);
        }
        else if(dealRequest.getStatus() == 3 && deals.get().getDealStatus() == 2 ){
            logger.info("rejected");
           deal.setDealStatus((short) 3);
            deal.setFinalQuote(0.00);
            vehicleDealsRepo.save(deal);
        }
        else if(dealRequest.getStatus() == 1 && deals.get().getDealStatus() == 3 ){
            logger.info("Already Rejected , trying to sold");
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(new JsonResponse("Action Not allowed. Already Rejected cannot Sold"));
        }
        else if(dealRequest.getStatus() == 3 && deals.get().getDealStatus() == 1 ){
            logger.info("Already Re , trying to reject");
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(new JsonResponse("Action Not allowed. Already sold cannot rejected"));
        }


        return ResponseEntity.status(200).body(new JsonResponse("Response Succesfully Submitted"));
    }

    @Override
    public ResponseEntity dealRequestResponseByDealId(long dealId) {
        Optional<VehicleDeals> deals = vehicleDealsRepo.findByDealId(dealId);
        if(deals.isEmpty()){
            return  ResponseEntity.status(404).body("");
        }
        DealResponse dealResponse = limitedMapEntitytoDTO(deals.get());
        return ResponseEntity.status(200).body(dealResponse);
    }

    @Override
    public ResponseEntity fetchDealRequestBySellerId(long uid,@PageableDefault(value = 100) Pageable pageable) {
        ResponseEntity responseEntity = ValidationUtils.validateUserId(uid);
        Page<VehicleDeals> deals = vehicleDealsRepo.findAllBySellerUserIdAndDealStatus(uid,(short) 2,pageable);
        List<DealResponse> response = new ArrayList<>();
        for(VehicleDeals deal:deals){
            DealResponse responseDeal = new DealResponse();
            responseDeal = sellerMapEntitytoDTO(deal);
            response.add(responseDeal);
        }
        return ResponseEntity.status(200).body(response);
    }

    @Override
    public ResponseEntity fetchDealRequestByBuyerId(long uid,@PageableDefault(value = 100) Pageable pageable) {
        ResponseEntity responseEntity = ValidationUtils.validateUserId(uid);
        Page<VehicleDeals> deals = vehicleDealsRepo.findAllByBuyerUserIdAndDealStatus(uid,(short) 2,pageable);
        List<DealResponse> response = new ArrayList<>();
        for(VehicleDeals deal:deals){
            DealResponse responseDeal = new DealResponse();
            responseDeal = limitedMapEntitytoDTO(deal);
            response.add(responseDeal);
        }
        return ResponseEntity.status(200).body(response);
    }


    @Override
    public ResponseEntity findUserDealStatus(long uid,String userId, short status) {
        Long userid;
        if(userId != null &&!userId.equals("")){
            logger.info("userId String type"+userId);
            userid = Long.parseLong(userId);
            logger.info("userid long : "+userid);
        }
        else{
            userid = (long) -1;
            logger.info("from else userid long : "+userid);
        }

        Optional<Users> user = userRepo.findByUserId(uid);
        if(!user.isPresent() ||  status <1 || status >4){
            return  ResponseEntity.status(404).body("");
        }
        if(user.get().getUserId() != userid || userid != uid){
            return  ResponseEntity.status(404).body("");
        }
        return ResponseEntity.status(200).body(vehicleDealsRepo.countDealStatusBySellerUserIdAndDealStatus(uid,status));
    }

    @Override
    public ResponseEntity findBySellerId(String userId,long uid,@PageableDefault(value = 10) Pageable pageable) {
        Long userid;
        if(userId != null &&!userId.equals("")){
            logger.info("userId String type"+userId);
            userid = Long.parseLong(userId);
            logger.info("userid long : "+userid);
        }
        else{
            userid = (long) -1;
            logger.info("from else userid long : "+userid);
        }

        Optional<Users> user = userRepo.findByUserId(uid);
        if(!user.isPresent()){
            return  ResponseEntity.status(404).body(new JsonResponse("User Not present"));
        }
        if(user.get().getUserId() != userid || userid != uid){
            return  ResponseEntity.status(404).body(new JsonResponse("User Session Not Valid"));
        }
        ResponseEntity responseEntity = ValidationUtils.validateUserId(uid);
        List<DealResponse> responses = new ArrayList<>();
        Page<VehicleDeals> deals = vehicleDealsRepo.findAllBySellerUserId(uid,pageable);
        for(VehicleDeals deal:deals){
            DealResponse response = new DealResponse();
            response = sellerMapEntitytoDTO(deal);
            responses.add(response);
        }
        return ResponseEntity.status(200).body(responses);
    }

    @Override
    public ResponseEntity findByBuyerId(String userId,long uid, Pageable pageable) {
        Long userid;
        if(userId != null &&!userId.equals("")){
            logger.info("userId String type"+userId);
            userid = Long.parseLong(userId);
            logger.info("userid long : "+userid);
        }
        else{
            userid = (long) -1;
            logger.info("from else userid long : "+userid);
        }

        Optional<Users> user = userRepo.findByUserId(uid);
        if(!user.isPresent()){
            return  ResponseEntity.status(404).body(new JsonResponse("User Not present"));
        }
        if(user.get().getUserId() != userid || userid != uid){
            return  ResponseEntity.status(404).body(new JsonResponse("User Session Not Valid"));
        }
        ResponseEntity responseEntity = ValidationUtils.validateUserId(uid);
        List<DealResponse> responses = new ArrayList<>();
        Page<VehicleDeals> deals = vehicleDealsRepo.findAllByBuyerUserId(uid,pageable);
        for(VehicleDeals deal:deals){
            DealResponse response = new DealResponse();
            response = buyerMapEntitytoDTO(deal);
            responses.add(response);
        }
        return ResponseEntity.status(200).body(responses);
    }

    @Override
    public ResponseEntity findByBuyerIdOrSellerId(String userId,long uid, Pageable pageable) {
        Long userid;
        if(userId != null &&!userId.equals("")){
            logger.info("userId String type"+userId);
            userid = Long.parseLong(userId);
            logger.info("userid long : "+userid);
        }
        else{
            userid = (long) -1;
            logger.info("from else userid long : "+userid);
        }

        Optional<Users> user = userRepo.findByUserId(uid);
        if(!user.isPresent()){
            return  ResponseEntity.status(404).body(new JsonResponse("User Not present"));
        }
        if(user.get().getUserId() != userid || userid != uid){
            return  ResponseEntity.status(404).body(new JsonResponse("User Session Not Valid"));
        }
        ResponseEntity responseEntity = ValidationUtils.validateUserId(uid);
        List<DealResponse> responses = new ArrayList<>();
        Page<VehicleDeals> deals = vehicleDealsRepo.findAllByBuyerUserIdOrSellerUserId(uid,pageable);
        for(VehicleDeals deal:deals){
            DealResponse response = new DealResponse();
            if(deal.getBuyer().getUserId() == uid){
                response = buyerMapEntitytoDTO(deal);
            }
            else if(deal.getSeller().getUserId() == uid){
                response = sellerMapEntitytoDTO(deal);
            }
            responses.add(response);
        }
        return ResponseEntity.status(200).body(responses);
    }
}
