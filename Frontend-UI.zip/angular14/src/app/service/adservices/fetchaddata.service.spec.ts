import { TestBed } from '@angular/core/testing';

import { FetchaddataService } from './fetchaddata.service';

describe('FetchaddataService', () => {
  let service: FetchaddataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FetchaddataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
