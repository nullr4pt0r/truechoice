package com.truebill.dev.listeners;


import com.truebill.dev.entity.SellVehicleAd;
import com.truebill.dev.entity.VehicleDeals;
import com.truebill.dev.repository.SellVehicleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.PrePersist;
import java.util.Optional;

//@Component
public class VehicleDealsListener {

    Logger logger = LoggerFactory.getLogger(VehicleDealsListener.class);
    @Autowired
    private SellVehicleRepository sellVehicleRepo;

    @Transactional
    @PrePersist
    public void CheckStatus(VehicleDeals deals){
        if(deals.getDealStatus() == 1){
            logger.info("in listener");
            Optional<SellVehicleAd> adOpt = sellVehicleRepo.findByvehicleId(deals.getVehicleId().getVehicleId());
            logger.info("before if status check in listener");
            if(adOpt.isPresent() && adOpt.get().getStatus() == (short)1){
                SellVehicleAd ad = adOpt.get();
                    ad.setStatus((short) 3);
                    logger.info("Gonna change the sell vehicle ad");
                    sellVehicleRepo.save(ad);
                    logger.info("Listener worked sucessfully");
                }
            }

        }
    }


