export interface DealRequest {
    vehicleId?: number;
    vehicleRegno?: string;
    dealId ?: number;
    sellerId?: number;
    buyerId ?: number;
    status?: number;
    buyerQuote ?: number;
    }