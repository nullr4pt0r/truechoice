package com.truebill.dev.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.util.Date;

@Getter
@Setter
@ToString

@Entity
@Table(name="users")
public class Users {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long userId;

    @NotEmpty(message = "Name Should not be Null")
    @NotBlank(message = "Name Should not be Empty / Blank")
    private String fullName;
    @Email(message = "Valid Email is required")
    private String email;
    @NotEmpty(message = "Username should not be empty")
    @Size(min = 5,max = 10,message = "Username Criteria not met . Minimum length 5 and Maximum length 10")
    @NotBlank(message = "Password Should not be Empty / Blank")
    private String username;
    //@Size(min = 8,max = 12,message = "Password Criteria not met . Minimum length 8 and Maximum length 12")
    @NotBlank(message = "Password Should not be Empty / Blank")
    @Column(length = 1024)
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String password;

    private String phoneNumber;
    private String location;
    private String userType = "user";

    @CreationTimestamp
    @Column(name = "created_At", nullable = false,updatable = false)
    private Date createdAt;

    @UpdateTimestamp
    @Column(name = "updated_At")
    private Date updatedAt;

    public Users() {
    }

    public Users(long userId, String fullName, String email, String username, String password, String phoneNumber, String location, String userType, Date createdAt, Date updatedAt) {
        this.userId = userId;
        this.fullName = fullName;
        this.email = email;
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.location = location;
        this.userType = userType;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Users(long userId, String fullName, String email, String username, String password, String phoneNumber, String location, String userType) {
        this.userId = userId;
        this.fullName = fullName;
        this.email = email;
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.location = location;
        this.userType = userType;
    }

    @JsonIgnore
    public Date getCreatedAt() {
        return createdAt;
    }

    @JsonIgnore
    public Date getUpdatedAt() {
        return updatedAt;
    }
}
