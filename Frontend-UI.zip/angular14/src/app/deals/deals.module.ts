import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SalesdataComponent } from './salesdata/salesdata.component';
import { FetchdealdataService } from '../service/dealService/fetchdealdata.service';
import { BuydataComponent } from './buydata/buydata.component';
import { ViewsalesComponent } from './viewsales/viewsales.component';
import { ViewordersComponent } from './vieworders/vieworders.component';
import { DataTablesModule } from 'angular-datatables';
import { NavBarsModule } from '../nav-bars/nav-bars/nav-bars.module';
import { SelloffersviewComponent } from './selloffersview/selloffersview.component';
import { BuyoffersviewComponent } from './buyoffersview/buyoffersview.component';
import { ViewdealbyidComponent } from './viewdealbyid/viewdealbyid.component';
import { NgxUiLoaderModule } from 'ngx-ui-loader';

@NgModule({
  declarations: [
    SalesdataComponent,
    BuydataComponent,
    ViewsalesComponent,
    ViewordersComponent,
    SelloffersviewComponent,
    BuyoffersviewComponent,
    ViewdealbyidComponent
  ],
  imports: [
    CommonModule,
    DataTablesModule,
    NavBarsModule,
    NgxUiLoaderModule
  ],
  providers:[FetchdealdataService],
  exports:[
    SalesdataComponent,
    BuydataComponent,
    ViewordersComponent,
    ViewsalesComponent,
    SelloffersviewComponent,
    BuyoffersviewComponent
  ]
})
export class DealsModule { }
