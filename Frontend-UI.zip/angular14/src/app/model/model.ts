export class Model {
    "modelId"!: number;
    "model"!: string;
    "year"!: string;
    "variant" !: string;
}
