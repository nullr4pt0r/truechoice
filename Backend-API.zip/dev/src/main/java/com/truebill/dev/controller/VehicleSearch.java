package com.truebill.dev.controller;

import com.truebill.dev.entity.SellVehicleAd;
import com.truebill.dev.repository.SellVehicleRepository;
import com.truebill.dev.service.VehicleSearchService;
import org.apache.tomcat.util.buf.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


//
@RestController
@CrossOrigin(origins = "*")
public class VehicleSearch {
    Logger logger = LoggerFactory.getLogger(VehicleSearch.class);
    @Autowired
    private SellVehicleRepository sellVehicleRepo;

    @Autowired
    private VehicleSearchService vehicleSearch;
//
//    @GetMapping("/search/auto")
//    public ResponseEntity searchVehicle(@RequestParam(required = false) String maker,
//                                        @RequestParam(required = false) String model,
//                                        @RequestParam(required = false) String year){
//        if(maker!= null && model != null){
//            return ResponseEntity.status(200).body(sellVehicleRepo.findByModelMakerMakerIgnoreCaseContainingAndModelModelIgnoreCaseContaining(maker,model));
//        }
//        else if(maker!=null && model == null && year == null){
//            return  ResponseEntity.status(200).body(sellVehicleRepo.findByModelMakerMaker(maker));
//        }
//        else if(maker == null && model!=null && year == null){
//            return ResponseEntity.status(200).body(sellVehicleRepo.findByModelModel(model));
//        }
//        else if(maker == null && model!=null && year != null){
//            return ResponseEntity.status(200).body(sellVehicleRepo.findByModelYear(year));
//
//        }
//        return  ResponseEntity.status(200).body(sellVehicleRepo.findFirst10ByOrderByCreatedAtDesc());
//    }
//
//}

    //    @GetMapping("/search/auto")
//    public ResponseEntity searchVehicle(@RequestParam(required = false, defaultValue = "") String maker,
//                                        @RequestParam(required = false, defaultValue = "") String model,
//                                        @RequestParam(required = false, defaultValue = "") String year,
//                                        @RequestParam(required = false, defaultValue = "") String variant, @PageableDefault(value=10) Pageable pageable) {
//        logger.info("search is : "+maker,model,year,variant);
//        if (maker == "" && model == "" && year == "" && variant == "") {
//            return ResponseEntity.status(200).body(sellVehicleRepo.findTop10ByStatusOrderByStatusDesc((short) 1));
//        } else {
//            return ResponseEntity.status(200).body(sellVehicleRepo.findByModelMakerMakerIgnoreCaseContainingAndModelModelIgnoreCaseContainingAndModelYearAndModelVariantContainingAndStatus(maker, model, year, variant, (short) 1,pageable));
//
//        }
//
//    }
    @GetMapping("/search/auto")
    public ResponseEntity searchVehicle(@RequestParam(name = "maker",required = false, defaultValue = "") String maker,
                                        @RequestParam(name = "model",required = false, defaultValue = "") String model,
                                        @RequestParam(name="year",required = false, defaultValue = "") String year,
//                                        @RequestParam(required = false, defaultValue = "") String variant,
                                        @RequestParam(name="owner",required = false, defaultValue = "") String owner,
                                        @RequestParam(name="finance",required = false, defaultValue = "") String finance,
                                        @RequestParam(name="kms",required = false, defaultValue = "") String kms,
                                        @RequestHeader(name = "Auth", required = false) String userId,
//                                        @RequestParam(name = "price",required = false, defaultValue = "") String price,
                                        @PageableDefault(value = 9) Pageable pageable) {
        short status = 1;
        logger.info("You are here search controller");
//        double rate;
//        if(price != null && !price.equals("")){
//             rate = Double.parseDouble(price);
//        }
//        else {
//             rate = 1000000.00;
//        }

        logger.info(userId);
        logger.info(maker);
        logger.info(model);
//        logger.info(year);
//        logger.info(variant);
//        logger.info((owner));
//        logger.info(String.valueOf(price));

//        if(model != null && !model.equals("") && maker != null && !maker.equals("")) {

//        }
//        else if(maker != null){
//            logger.info("in maker");
//            model = "";
//            Page<SellVehicleAd> ads = sellVehicleRepo.findAllByMakerModel(maker,model,pageable);
//            for (SellVehicleAd a : ads) {
//                vehicles.add(a);
//            }
//        }
//        else if(model != null && model)

        return ResponseEntity.status(200).body(vehicleSearch.searchVehicles(maker,model,owner,finance,kms,year,userId,pageable));
    }


//        if (maker != null && model != null) {
//            Page<SellVehicleAd> ads = sellVehicleRepo.findByModelMakerMakerIgnoreCaseContainingAndModelModelIgnoreCaseContainingAndStatus(maker, model, status,pageable);
//            for(SellVehicleAd ad:ads.getContent()){
//                vehicles.add(ad);
//            }
//            return ResponseEntity.status(200).body(vehicles);
//        } else if (maker != null) {
//            Page<SellVehicleAd> ads = sellVehicleRepo.findByModelMakerMakerAndStatus(maker, status,pageable);
//            for(SellVehicleAd ad:ads.getContent()){
//                vehicles.add(ad);
//            }
//            return ResponseEntity.status(200).body(vehicles);
//        } else if (model != null ) {
//            Page<SellVehicleAd> ads = sellVehicleRepo.findByModelModelAndStatus(model, status,pageable);
//            for(SellVehicleAd ad:ads.getContent()){
//                vehicles.add(ad);
//            }
//            return ResponseEntity.status(200).body(vehicles);
//        } else if (maker == null && model == null && year != null && owner == null && variant == null && Double.isNaN(price)) {
//            Page<SellVehicleAd> ads = sellVehicleRepo.findByModelYearAndStatus(year,status,pageable);for(SellVehicleAd ad:ads.getContent()){
//                vehicles.add(ad);
//            }
//            return ResponseEntity.status(200).body(vehicles);
//        }
//        else if(maker == null && model == null && owner != null && year == null && variant == null && Double.isNaN(price)){
//            Page<SellVehicleAd> ads = sellVehicleRepo.findByVehicleOwnercountAndStatus(owner,status,pageable);
//            for(SellVehicleAd ad:ads.getContent()){
//                vehicles.add(ad);
//            }
//            return ResponseEntity.status(200).body(vehicles);
//        }
//        else if(maker == null && model == null && owner == null && year == null && variant != null && Double.isNaN(price)){
//            Page<SellVehicleAd> ads = sellVehicleRepo.findByModelVariantContainingAndStatus(variant,status,pageable);
//            for(SellVehicleAd ad:ads.getContent()){
//                vehicles.add(ad);
//            }
//        }
//        else if(maker == null && model == null && owner == null && year == null && variant == null && Double.isFinite(price)){
//            Page<SellVehicleAd> ads = sellVehicleRepo.findByVehiclePriceLessThanAndStatus(price,status,pageable);
//            for(SellVehicleAd ad:ads.getContent()){
//                vehicles.add(ad);
//            }
//        }
//        // Check if any of the parameters are null or empty
//        else if (maker != null && !maker.isEmpty() || model != null && !model.isEmpty() || year != null && !year.isEmpty() || variant != null && !variant.isEmpty()) {
//            // Call the repository method and pass in the parameters and the status
//            Page<SellVehicleAd> ads = sellVehicleRepo. findByModelMakerMakerIgnoreCaseContainingAndModelModelIgnoreCaseContainingAndModelYearAndModelVariantContainingAndVehicleOwnercountAndVehiclePriceAndStatus(maker, model, year, variant, owner,price,status, pageable);
////            List<SellVehicleAd> adList = new ArrayList<>();
//            for(SellVehicleAd ad:ads.getContent()){
//                vehicles.add(ad);
//            }
//        } else {
//
//            Page<SellVehicleAd> ads = sellVehicleRepo.findTop10ByStatusOrderByStatusDesc(status,pageable);
//            logger.info(ads.toString());
//
//            for(SellVehicleAd ad:ads.getContent()){
//                vehicles.add(ad);
//            }
//        }
    // Return the list of vehicles

    @GetMapping("/view/{id}")
    public  ResponseEntity searchvechicleById(@PathVariable long id){
        return vehicleSearch.viewLimitedDetails(id);
    }


}




