package com.truebill.dev.controller;

import com.truebill.dev.entity.SellVehicleAd;
import com.truebill.dev.request.SellVehicleAdRequest;
import com.truebill.dev.request.SellVehicleAdUpdateRequest;
import com.truebill.dev.service.SellVehicleService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;


@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/seller")
public class SellerController {
    Logger logger = LoggerFactory.getLogger(SellerController.class);
    @Autowired
    private SellVehicleService sellVehicleService;
    @GetMapping("")
    public String showInfo(){
        return  "Seller Page";
    }

    @GetMapping("/myauto/{uid}")
    public ResponseEntity sellerVehicle(@PathVariable Long uid,@PageableDefault(value = 100) Pageable pageable){
         return sellVehicleService.findAllAuto(uid,pageable);
    }

    @PostMapping("/newauto")
    public ResponseEntity createAd(@Valid @RequestBody SellVehicleAdRequest vehicle){
        return sellVehicleService.createAd(vehicle);
    }
    @GetMapping("/myauto/{uid}/count")
    public ResponseEntity countAdByUser(@PathVariable long uid){
        return sellVehicleService.findAllAdByUser(uid);
    }

    @GetMapping("auto/{vid}")
    public  ResponseEntity vehicleId(@PathVariable long vid){
        return  sellVehicleService.findAdById(vid);
    }

    @PutMapping("/edit/auto/{vid}")
    public ResponseEntity updateAd( @PathVariable long vid,@Valid @RequestBody SellVehicleAdRequest ad)
    {
        return sellVehicleService.updateSellVehicleAdBySellerIdAndVehicleId(vid,ad);
    }



}
