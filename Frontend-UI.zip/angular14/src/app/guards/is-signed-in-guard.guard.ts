import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { SessionService } from '../service/authentication/session.service';

@Injectable({
  providedIn: 'root'
})
export class IsSignedInGuardGuard implements CanActivate {
  constructor(private sessionService:SessionService,private router:Router){}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree
    {
      if(this.sessionService.isAuthenticated){
        console.log("Is signed in : "+this.sessionService.isAuthenticated);
        this.router.navigate(["/home"]);
        return false;
      }

    return true;
  }

}
