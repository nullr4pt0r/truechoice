package com.truebill.dev.repository;

import com.truebill.dev.entity.VehicleMaker;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VehicleMakerRepository extends JpaRepository<VehicleMaker,Long> {

    @Query("SELECT DISTINCT m.maker  FROM VehicleMaker m")
    List<String> findDistinctByMaker();

}
