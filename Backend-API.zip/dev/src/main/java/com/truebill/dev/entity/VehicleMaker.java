package com.truebill.dev.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "vehiclemaker")
public class VehicleMaker {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long makerId;
    private String maker;
    private String vehicleType;

    @OneToMany(mappedBy = "maker",fetch = FetchType.LAZY)
    @JsonManagedReference
    @JsonIgnore
    private List<VehicleModel> model;



    public VehicleMaker() {
    }


    public VehicleMaker(long makerId, String maker, String vehicleType, List<VehicleModel> model) {
        this.makerId = makerId;
        this.maker = maker;
        this.vehicleType = vehicleType;
        this.model = model;
    }

    public long getMakerId() {
        return makerId;
    }

    public void setMakerId(long makerId) {
        this.makerId = makerId;
    }

    public String getMaker() {
        return maker;
    }

    public void setMaker(String maker) {
        this.maker = maker;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    @JsonIgnore
    public List<VehicleModel> getModel() {
        return model;
    }

    public void setModel(List<VehicleModel> model) {
        this.model = model;
    }
}
