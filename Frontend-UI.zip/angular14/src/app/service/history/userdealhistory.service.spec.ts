import { TestBed } from '@angular/core/testing';

import { UserdealhistoryService } from './userdealhistory.service';

describe('UserdealhistoryService', () => {
  let service: UserdealhistoryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserdealhistoryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
