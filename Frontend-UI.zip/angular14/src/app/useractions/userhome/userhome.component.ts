import { Component, OnInit } from '@angular/core';
import { UserdataService } from '../../service/userdata/userdata.service';
import { FetchaddataService } from '../../service/adservices/fetchaddata.service';
import { Router } from '../../../../node_modules/@angular/router';
import { FetchdealdataService } from '../../service/dealService/fetchdealdata.service';
import { response } from '../../../../node_modules/@types/express';

@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrls: ['./userhome.component.scss']
})
export class UserhomeComponent implements OnInit {
  buyOffers : any = 0;
  sellOffers : any = 0;
  dealSold : any = 0;
  dealBought : any  = 0;
  responsedata:any = 0;
  adcount: any;
  data: any;
  carditems: { number: number; class: string; name: string; link: string; content1: string; content2: string; count: any; button: string;goto:string }[] = [];

  constructor(private userdataservice: UserdataService, private adservice: FetchaddataService,private router:Router,private dealService:FetchdealdataService) { }

  ngOnInit(): void {

    this.data = this.userdataservice.getData();
    console.log(this.userdataservice.getData());
    this.dealService.getSalesCountbyUserId(this.data.userid).subscribe(response =>{
      this.dealSold = response;
      console.log(this.dealSold);
      console.log("sales : "+response);
    });
    this.dealService.getBuyCountbyUserId(this.data.userid).subscribe(response =>{
      this.dealBought = response;
      console.log("buy : "+response);
    });
    this.dealService.getOfferCountbyBuyerId(this.data.userid).subscribe(response =>{
      this.buyOffers = response;
      console.log("buy : "+response);
    });
    this.dealService.getOfferCountbySellerId(this.data.userid).subscribe(response =>{
      this.sellOffers = response;
      console.log("buyoffers : "+response);
    });
    console.log("deals sold"+this.dealSold);
      console.log("deals bought"+this.dealBought);
    this.adservice.getAdbyUserId(this.data.userid).subscribe(response => {
      this.responsedata = response;

      // if(this.responsedata === 0){
      //   this.responsedata = 0
      // }
      console.log("response data" + this.responsedata);


      this.createcard();

    }, error => this.createcard());


  }

  ngAfterViewInit():void{
    this.dealService.getSalesCountbyUserId(this.data.userid).subscribe(response =>{
      this.dealSold = response;
      console.log(this.dealSold);
      console.log("sales : "+response);
    });
    this.dealService.getBuyCountbyUserId(this.data.userid).subscribe(res =>{
      this.dealBought = res;
      console.log("buy : "+res);
    });
    this.dealService.getOfferCountbyBuyerId(this.data.userid).subscribe(res =>{
      this.buyOffers = res;
      console.log("buy : "+res);
    });
    this.dealService.getOfferCountbySellerId(this.data.userid).subscribe(res =>{
      this.sellOffers = res;
      console.log("buyoffers : "+res);
    });
  }

  createcard(){

    this.carditems = [
      {
        number: 1,
        class: "bg-success-color",
        name: "Ads Posted",
        link: "1",
        content1: "Successfully posted",
        content2: " ads",
        count: this.responsedata,
        button: "View Ads",
        goto : "viewad"
      },
      {
        number: 2,
        class: "bg-danger-color",
        name: "Cars sold",
        link: "#",
        content1: "Successfully sold",
        content2: " cars",
        count: this.dealSold,
        button: "View cars",
        goto : "viewcar"
      },
      {
        number: 3,
        class: "bg-custom-turquoise",
        name: "Voila! Ad got offers",
        link: "#",
        content1: "Received",
        content2: " offers",
        count: this.sellOffers,
        button: "Check offers",
        goto : "checkoffer"
      },
      {
        number: 4,
        class: "bg-secondary-color",
        name: "Buy offers made",
        link: "#",
        content1: "Successfully made",
        content2: " offers",
        count: this.buyOffers,
        button: "View offers",
        goto : "viewoffer"
      },
      {
        number: 5,
        class: "bg-custom-blue",
        name: "Cars Bought",
        link: "#",
        content1: "Successfully bought",
        content2: " car",
        count: this.dealBought,
        button: "View orders",
        goto:"vieworder"
      },{
        number: 6,
        class: "bg-custom-color",
        name: "History",
        link: "#",
        content1: "See all history",
        content2: " at one place",
        count: '',
        button: "View History",
        goto:"viewhistory"
      },
      {
        number: 6,
        class: "bg-custom-purple",
        name: "Coming Future...",
        link: "#",
        content1: "Dev busy trying new features",
        content2: "",
        count:'',
        button: "Coming Soon...",
        goto:"quotes"
      },

    ]
  }

  goTo(place:string){
    if(place == "viewad"){
        this.router.navigate(['/viewads'])
    }
    else if(place == "vieworder"){
      this.router.navigate(['/orders']);
    }
    else if(place == "viewcar"){
      this.router.navigate(['/sales']);
    }
    else if(place == "checkoffer"){
      this.router.navigate(['view/offers/sell']);
    }
    else if(place == "viewoffer"){
      this.router.navigate(['view/offers/buy']);
    }
    else if(place == "viewhistory"){
      this.router.navigate(['history']);
    }
  }

}
