import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyoffersviewComponent } from './buyoffersview.component';

describe('BuyoffersviewComponent', () => {
  let component: BuyoffersviewComponent;
  let fixture: ComponentFixture<BuyoffersviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuyoffersviewComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BuyoffersviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
