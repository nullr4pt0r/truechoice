package com.truebill.dev.request;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class NewModel {

    private long makerId;
    @NotEmpty(message = "Maker cannot be empty")
    private  String model;
    @NotEmpty(message = "Year cannot be empty")
    private String year;
    @NotEmpty(message = "variant cannot be empty")
    private String variant;
}
