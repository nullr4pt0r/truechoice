import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SessionService } from '../authentication/session.service';
import { Router } from '@angular/router';
import {Observable,throwError} from 'rxjs';
import {catchError} from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class UserdealhistoryService {

  constructor(private httpClient:HttpClient, private sessionService:SessionService, private router:Router) { }

  private baseURL = "http://localhost:9876/api/v1/deals";

  getHistoryBySellerId(id:number):Observable<object>{
    console.log(id);
    return this.httpClient.get<object>(`${this.baseURL}/seller/${id}/history`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }

  getHistoryByUserId(id:number):Observable<object>{
    console.log(id);
    return this.httpClient.get<object>(`${this.baseURL}/history/${id}`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }
  getHistoryByBuyerrId(id:number):Observable<object>{
    console.log(id);
    return this.httpClient.get<object>(`${this.baseURL}/buyer/${id}/history`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }


}
