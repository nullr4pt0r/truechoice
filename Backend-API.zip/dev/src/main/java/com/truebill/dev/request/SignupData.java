package com.truebill.dev.request;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class SignupData {

    private String fullName;
    private String email;
    private String password;
    private String username;
    private String phoneNumber;
    private String location;

}
