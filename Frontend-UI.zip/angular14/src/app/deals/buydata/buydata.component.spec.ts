import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuydataComponent } from './buydata.component';

describe('BuydataComponent', () => {
  let component: BuydataComponent;
  let fixture: ComponentFixture<BuydataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuydataComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BuydataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
