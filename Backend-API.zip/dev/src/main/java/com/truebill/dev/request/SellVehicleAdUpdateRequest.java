package com.truebill.dev.request;

public class SellVehicleAdUpdateRequest {
    private String vehicleRegNo;
    private long modelId;
    private String vehicleKms;
    private String VehicleOwnercount;
    private double vehiclePrice;
    private String comments;
    private long sellerId;
    private String vehicleFinance;

}
