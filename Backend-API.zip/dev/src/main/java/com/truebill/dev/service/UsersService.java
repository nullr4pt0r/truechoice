package com.truebill.dev.service;

import com.truebill.dev.DTO.Login;
import com.truebill.dev.DTO.ValidUser;
import com.truebill.dev.entity.Users;
import com.truebill.dev.request.UserUpdateData;
import org.apache.coyote.Response;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface UsersService {

    ResponseEntity<ValidUser> createUser(Users User);
    ResponseEntity<ValidUser> VerifyUser(Login login);
    ResponseEntity<Users> findUser(long uid);

    ResponseEntity getAllUser(Pageable pageable);


    ResponseEntity<ValidUser> updateUser(long uid, UserUpdateData user);

}
