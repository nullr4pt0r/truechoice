import { Component, OnInit, ViewChild } from '@angular/core';
import { Ad } from '../../../model/ad';
import { AdcrudService } from '../../../service/adservices/adcrud.service';
import { UserdataService } from '../../../service/userdata/userdata.service';
import { Adcrud } from '../../../model/Adcrudmodel/adcrud';
import { Router } from '../../../../../node_modules/@angular/router';
import { DataTableDirective } from '../../../../../node_modules/angular-datatables';
import { Subject } from 'rxjs';




@Component({
  selector: 'app-view-ads',
  templateUrl: './view-ads.component.html',
  styleUrls: ['./view-ads.component.scss']
})
export class ViewAdsComponent implements OnInit {


  ads !: Adcrud[];
  id !: number;
  currentPage :number = 1;

  page:number = 0;
  query:any="?";
  dtOptions : DataTables.Settings = {};
  showContent : any;
  constructor(private adcrudService:AdcrudService,private router:Router , private userdataService: UserdataService) { }

  ngOnInit(): void {


    this.dtOptions = {
      pagingType: 'full_numbers',
      lengthMenu: [5,10,15,20],
      pageLength : 10,
      processing: true
    },
    setTimeout(()=>this.showContent=true, 250),
    this.id = this.userdataService.getData().userid;
    console.log(this.id);
    this.query+= `&page=${this.page}`;
    this.getAds();


  }

  view(id:number){
    console.log(id);
    this.router.navigate(["/viewad/",id]);
  }

  modifyAd(id:number){
    console.log(id);
    this.router.navigate(['/editad',id]);
  }
  getAds() {
    this.adcrudService.getAdsByUserId(this.id, this.query).subscribe(response => {
      this.ads = response;
    });
  }

}
