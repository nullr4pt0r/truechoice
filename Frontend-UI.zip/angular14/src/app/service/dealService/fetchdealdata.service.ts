import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SessionService } from '../authentication/session.service';
import { Router } from '@angular/router';
import {Observable,throwError} from 'rxjs';
import {catchError} from 'rxjs/operators';
import { DealRequest } from '../../model/dealRecords/deal-request';


@Injectable({
  providedIn: 'root'
})
export class FetchdealdataService {
  constructor(private httpClient:HttpClient, private sessionService:SessionService, private router:Router) { }



  private baseURL = "http://localhost:9876/api/v1/deals/";

  getSalesCountbyUserId(id:number):Observable<object>{
    console.log(id);
    return this.httpClient.get<object>(`${this.baseURL}/count/${id}/sell`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }
  getOfferCountbySellerId(id:number):Observable<object>{
    console.log(id);
    return this.httpClient.get<object>(`${this.baseURL}/${id}/offers/sell`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }
  getOfferCountbyBuyerId(id:number):Observable<object>{
    console.log(id);
    return this.httpClient.get<object>(`${this.baseURL}/${id}/offers/buy`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }

  createNewDealRequest(dealRequest:DealRequest):Observable<Object>{
    console.log("dealrequest from service :"+dealRequest);
    console.log(dealRequest);
    return this.httpClient.post<object>(`${this.baseURL}new/request`,dealRequest)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }

  sellerDealAction(dealRequest:DealRequest):Observable<object>{
    console.log("deal action from service: "+dealRequest);
    return this.httpClient.post<object>(`${this.baseURL}/seller/action`,dealRequest)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }

  getDealRequestResponseByDealId(id:number):Observable<object>{
    console.log(id);
    return this.httpClient.get<object>(`${this.baseURL}/request/${id}`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }
  getAllDealPendingBySellerId(id:number):Observable<object>{
    console.log(id);
    return this.httpClient.get<object>(`${this.baseURL}/users/${id}/seller`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }

  getAllDealPendingByBuyerId(id:number):Observable<object>{
    console.log(id);
    return this.httpClient.get<object>(`${this.baseURL}/${id}/buyer`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }

  getBuyCountbyUserId(id:number):Observable<object>{
    console.log(id);
    return this.httpClient.get<object>(`${this.baseURL}/count/${id}/buy`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }

  getDealResponseBySellerIdAndDealId(dealid:number,uid:number){
    return this.httpClient.get<object>(`${this.baseURL}sell/${uid}/${dealid}`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }
  getDealResponseByBuyerIdAndDealId(dealid:number,uid:number){
    return this.httpClient.get<object>(`${this.baseURL}buy/${uid}/${dealid}`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
  }



  getAllDealDataBySellerId(uid:number){
    return this.httpClient.get<object>(`${this.baseURL}/${uid}/sales`)
    .pipe(
      catchError((errorRes)=>{
        console.error("Error response from service : "+errorRes);
        let errorMessage = "An Error Occured . Try again later";
        if (errorRes.error && errorRes.error.error instanceof Array){
        // if(!errorRes.error || !errorRes.error.message) {
         errorMessage = errorRes.error.error[0];
        // return throwError(errorMessage);
        }
         else {
          errorMessage = errorRes.error;
        }
        return throwError(errorMessage);
      })

    );
}


getAllDealDataByBuyerId(uid:number){
  return this.httpClient.get<object>(`${this.baseURL}/${uid}/orders`)
  .pipe(
    catchError((errorRes)=>{
      console.error("Error response from service : "+errorRes);
      let errorMessage = "An Error Occured . Try again later";
      if (errorRes.error && errorRes.error.error instanceof Array){
      // if(!errorRes.error || !errorRes.error.message) {
       errorMessage = errorRes.error.error[0];
      // return throwError(errorMessage);
      }
       else {
        errorMessage = errorRes.error;
      }
      return throwError(errorMessage);
    })

  );

}
}