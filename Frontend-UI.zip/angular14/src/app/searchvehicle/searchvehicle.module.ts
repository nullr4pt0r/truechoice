import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchvehicleComponent } from './searchvehicle/searchvehicle.component';
import { FormsModule } from '../../../node_modules/@angular/forms';
import { NavBarsModule } from '../nav-bars/nav-bars/nav-bars.module';
import { NgxUiLoaderModule } from '../../../node_modules/ngx-ui-loader';



@NgModule({
  declarations: [
    SearchvehicleComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    NavBarsModule,
    NgxUiLoaderModule
  ],
  exports:[
    SearchvehicleComponent
  ]
})
export class SearchvehicleModule { }
