import { Component } from '@angular/core';
import { LoginService } from './service/authentication/login.service';
import { Router } from '@angular/router';
import { SessionService } from './service/authentication/session.service';

import { NgxUiLoaderService } from "ngx-ui-loader";
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'TrueChoice';
  sideNavStatus: boolean = false;

  constructor(public authService: LoginService, private ngxService: NgxUiLoaderService, private router: Router, public sessionService: SessionService) {

  }
  ngOnint(): void {
    this.sessionService.checkSession();

  }


  login() {
    this.router.navigate(['/login']);
  }

  logout() {
    this.authService.logout();
  }
}

