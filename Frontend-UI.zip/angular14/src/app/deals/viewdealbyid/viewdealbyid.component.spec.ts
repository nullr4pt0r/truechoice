import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewdealbyidComponent } from './viewdealbyid.component';

describe('ViewdealbyidComponent', () => {
  let component: ViewdealbyidComponent;
  let fixture: ComponentFixture<ViewdealbyidComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewdealbyidComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewdealbyidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
