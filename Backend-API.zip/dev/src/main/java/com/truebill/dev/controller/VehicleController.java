package com.truebill.dev.controller;

import com.truebill.dev.repository.VehicleMakerRepository;
import com.truebill.dev.repository.VehicleModelRepository;
import com.truebill.dev.request.NewMaker;
import com.truebill.dev.request.NewModel;
import com.truebill.dev.service.VehicleMakerModelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/vehicle")
public class VehicleController {

    @Autowired
    private VehicleMakerModelService makerModelService;
    @Autowired
    private VehicleMakerRepository makerRepo;
    @Autowired
    private VehicleModelRepository modelRepo;

    @GetMapping("/makers")
    public ResponseEntity getAllMaker(){
        return ResponseEntity.status(200).body(makerRepo.findAll());
    }

    @GetMapping("/models")
    public ResponseEntity getAllModel(){
        return ResponseEntity.status(200).body(modelRepo.findAll());
    }

    @GetMapping("/maker/{id}/model")
    public ResponseEntity getMakerModel(@PathVariable long id){
        return ResponseEntity.status(200).body(modelRepo.findByMakerMakerId(id));
    }
    @PostMapping("/new/Maker")
    public  ResponseEntity createNewMaker(@Valid @RequestBody NewMaker maker){
        return makerModelService.addNewMaker(maker);
    }
    @PostMapping("/new/model")
    public  ResponseEntity createNewModel(@Valid @RequestBody NewModel model){
        return makerModelService.addNewModel(model);
    }

    @GetMapping("/all/model")
    public ResponseEntity allModels(){
        return ResponseEntity.status(200).body(modelRepo.findDistinctByModel());
    }

    @GetMapping("/all/year")
    public ResponseEntity allYears(){
        return ResponseEntity.status(200).body(modelRepo.findDistinctByYear());
    }

    @GetMapping("/all/maker")
    public ResponseEntity allMakers(){
        return ResponseEntity.status(200).body(makerRepo.findDistinctByMaker());
    }

}
