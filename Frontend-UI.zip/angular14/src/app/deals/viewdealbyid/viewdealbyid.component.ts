import { Component, OnInit } from '@angular/core';
import { DealRecord } from '../../model/dealRecords/dealrecord';
import { ActivatedRoute } from '../../../../node_modules/@angular/router';
import { FetchdealdataService } from '../../service/dealService/fetchdealdata.service';

@Component({
  selector: 'app-viewdealbyid',
  templateUrl: './viewdealbyid.component.html',
  styleUrls: ['./viewdealbyid.component.scss']
})
export class ViewdealbyidComponent implements OnInit {

  ad:DealRecord = new DealRecord();
  id!:number;
  constructor(private route:ActivatedRoute, private dealService:FetchdealdataService) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    console.log(this.id);
    this.dealService.getDealRequestResponseByDealId(this.id).subscribe(response => {
      this.ad = response as DealRecord;
    });
  }



}

