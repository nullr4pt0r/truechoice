import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SessionService {
  userId?: any;
  sessionId!: any;
  isAuthenticated!:boolean;
  isNotAuthenticated!:boolean ;
    // true;

  constructor() {
    this.userId = localStorage.getItem('userid');
    this.userId = parseInt(this.userId);
    this.checkSession();
    // console.log("userId is : "+this.userId);
  }

  checkSession(): boolean {
    if (localStorage.getItem('userid') == this.userId && localStorage.getItem('sessionid') == (this.userId) + 1 && sessionStorage.getItem('userid') == this.userId && sessionStorage.getItem('sessionid') == (this.userId) + 1 ) {
      // console.log("From session check : "+this.userId);
      // console.log("fron if check : "+(sessionStorage.getItem('userid') == this.userId && sessionStorage.getItem('sessionid') == (this.userId) + 1));
      this.isAuthenticated = true;
      this.isNotAuthenticated =  false;
      console.log("this.isAuthenticated");
      return true;
    }
    else {
      this.isAuthenticated = false;
      this.isNotAuthenticated =  true;
      // console.log("From session check : Session not found");
      // console.log("From session check : "+this.userId);
      // console.log("From session check : "+sessionStorage.getItem('userid'));
      // console.log("From session check : "+ (this.userId) + 1);
      return false;
    }
  }

  setSession(data: any): boolean {
    sessionStorage.setItem("userid", data.uid);
    sessionStorage.setItem("username", data.username);
    sessionStorage.setItem("rootAuth", data.userType);
    sessionStorage.setItem("sessionid", data.uid + 1);
    localStorage.setItem("userid", data.uid);
    localStorage.setItem("username", data.username);
    localStorage.setItem("rootAuth", data.userType);
    localStorage.setItem("sessionid", data.uid + 1);
    const UserData = {userid:data.uid,username:data.username,rootAuth:data.usertype,sessionid:data.uid+1};
    const myJSON = JSON.stringify(UserData);
    sessionStorage.setItem("userJson", myJSON);
    localStorage.setItem("userJson", myJSON);
    return true;
  }

  setUpdatedSession(data:any){
    sessionStorage.setItem("username", data.username);
    // sessionStorage.setItem("rootAuth", data.userType);
    localStorage.setItem("username", data.username);
    // localStorage.setItem("rootAuth", data.userType);
    const UserData = {userid:data.uid,username:data.username,rootAuth:data.usertype,sessionid:data.uid+1};

  }



}
