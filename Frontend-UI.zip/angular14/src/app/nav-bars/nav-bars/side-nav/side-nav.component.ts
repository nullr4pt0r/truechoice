import { Component, OnInit, Input } from '@angular/core';
import { Router } from '../../../../../node_modules/@angular/router';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.scss']
})
export class SideNavComponent implements OnInit {
  @Input() sideNavStatus : boolean = false;

  sidebarItems = [
    {
        number: '1',
        name: 'home',
        goto: 'home',
        icon: 'fa-solid fa-house',
    },
    {
      number: '2',
      name: 'sell car',
      goto:'sell',
      icon: 'fa-solid fa-money-bill-wave-alt',
      class: 'pl-3'
  },
  {
    number: '3',
    name: 'buy car',
    goto:'buy',
    icon: 'fa-solid fa-car',
    class: 'pl-1'
},
{
  number: '4',
  name: 'history',
  goto:'orders',
  icon: 'fa-solid fa-history ml',
},
{
  number: '5',
  name: 'profile',
  goto:'profile',
  icon: 'fa-solid fa-user',
},

  ]

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  goTo(name:string){
    if(name === 'home'){
      this.router.navigate(['/home']);
    }
    else if(name === 'sell'){
      this.router.navigate(['/sellvehicle']);
    }
    else if(name == 'profile'){
      this.router.navigate(['/myprofile']);
    }
    else if(name == 'buy'){
      this.router.navigate(['/buy']);
    }
    else if(name == 'orders'){
      this.router.navigate(['/history']);
    }
  }

}
