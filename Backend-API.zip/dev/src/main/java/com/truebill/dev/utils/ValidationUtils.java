package com.truebill.dev.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class ValidationUtils {
    static Logger logger = LoggerFactory.getLogger(ValidationUtils.class);
    public static ResponseEntity validateUserId(Long uid) {
        if (uid == null || uid < 0) {
            logger.info("From Validation utils : uid check => "+uid);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid user id");
        }
        return null;
    }
}
